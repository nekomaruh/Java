package Aplicacion;
import ucn.*;
import java.io.IOException;
import java.lang.Math;
import java.util.Scanner;

/**
 * @author Johan Ordenes / Cecilia Rojas
 * Nota 1: Se omiten las tildes en la ejecuci�n del programa.
 * Nota 2: Se omite el manejo de excepciones.
 */

public class App {
	/**
	 * @param cod
	 * @param nom
	 * @param a�o
	 * @param precio
	 * @param porcGanancia
	 * @param cantVendida
	 * @param categorias
	 * M�todo para leer el archivo "juegos.txt" y "categorias.txt", guarda en la matriz y vectores correspondientes.
	 */
	public static void leerArchivos(String[]cod,String[]nom,int[]ano,double[]precio,double[]porcGanancia,int[]cantVendida,String[][]categorias){
		int pos=0;		
		try{
			ArchivoEntrada archJuegos = new ArchivoEntrada("juegos.txt");
			while(!archJuegos.isEndFile()){
				Registro reg = archJuegos.getRegistro();
				cod[pos] = reg.getString();
				nom[pos] = reg.getString();
				ano[pos] = reg.getInt();
				precio[pos] = reg.getDouble();
				porcGanancia[pos] = reg.getDouble();
				cantVendida[pos] = reg.getInt();
				pos++;
			}
		}catch(IOException ex){
			StdOut.println("No se puede leer el archivo 'juegos.txt'");
		}
		pos=0;
		try{
			ArchivoEntrada archCategorias = new ArchivoEntrada("categorias.txt");
			while(!archCategorias.isEndFile()){
				Registro reg = archCategorias.getRegistro();
				for(int x=0; x<2;x++){
					categorias[pos][x]=reg.getString();
				}
				pos++;
				}
		}catch(IOException ex){
			StdOut.println("No se puede leer el archivo 'categorias.txt'");
		}
	}
	
	/**
	 * @param gananciaCopia
	 * @param precio
	 * @param porcGanancia
	 * @param cantVendida
	 * Calcula la ganancia por copias vendidas y agrega los valores dentro del vector correspondiente
	 */
	public static void calcularGananciasPorCopia(double[]gananciaCopia,double[]precio,double[]porcGanancia,int[]cantVendida){
		for(int x=0; x<1000; x++){
			gananciaCopia[x]=precio[x]*(porcGanancia[x]/100)*cantVendida[x];
		}
	}
	
	/**
	 * @param a�o
	 * @param nom
	 * @param cantVendida
	 * @param porcGanancia
	 * Resoluci�n del RF1 con los par�metros obtenidos desde el main
	 */
	public static void RF1(int[]ano,String[]nom,int[]cantVendida,double[]gananciaCopia){
		int anoLanzamiento = 0;
		int mayorCantVendidos = 0;
		boolean existe = false;
		int posMasVendidoPorAno = -1;

		StdOut.print("\r     Ingrese ano de lanzamiento: ");
		anoLanzamiento = StdIn.readInt();
		
		// Calcula la mayor cantidad de vendidos
		for(int x=0; x<1000; x++){
			if(anoLanzamiento==ano[x]){
				existe=true;
				if(cantVendida[x]>mayorCantVendidos){
					mayorCantVendidos=cantVendida[x];
					posMasVendidoPorAno=x;
				}
			}
		}
		// Despliega por pantalla el nombre y cantidad del juego mas vendido por a�o
		for(int x=0; x<1000; x++){
			if(posMasVendidoPorAno==x){
				StdOut.println("\r     El juego mas vendido en el ano "+anoLanzamiento+" es '"+ nom[x]+"' con "+ cantVendida[x]+" cantidades vendidas.");
			}
		}
		// Calcula el mayor de las ganacias
		double mayorGanancias=-999;
		int posMayorGanancia=-1;
		for(int x=0; x<1000;x++){
			if(anoLanzamiento==ano[x]){
				if(gananciaCopia[x]>mayorGanancias){
					mayorGanancias=gananciaCopia[x];
					posMayorGanancia=x;
				}
			}
		}
		// Despliega por pantalla el juego con mayor ganancia con respecto al a�o
		if(anoLanzamiento!=0 && existe==true){
			StdOut.println("     El juego con mayor ganancia es '"+nom[posMayorGanancia]+"' con $"+ Math.round(gananciaCopia[posMayorGanancia])+" recaudados.");
		}
		
		// Si no existe la fecha, se devuelve al menu de opciones
		if(existe==false || anoLanzamiento==0){
			StdOut.println("\r     No existe juego registrado para ese ano.");
			existe=true;
		}
	}
	
	/**
	 * @param catIngresadas
	 * @param categorias
	 * @param gananciaCopia
	 * @param gananciasPorCategoria
	 * Resoluci�n del RF2 con los par�metros obtenidos desde el main
	 * @throws IOException 
	 */
	public static void RF2(String[]cod,String[]newCodPorCat,String[]catIngresadas, String[][]categorias,double[]gananciaCopia) throws IOException{
		int pos=0;
		boolean ingresar = false;
		boolean omitir = false;
		String catIngresada=" ";
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		
		// Ingresa las categor�as preguntadas por pantalla a un vector nuevo
		StdOut.print("\r     Ingrese categoria (-1 para terminar): ");
		catIngresada = sc.nextLine();
		while(catIngresada.equals("-1")){
			StdOut.println("     �Error!, Ingrese una categoria v�lida");
			StdOut.print("     Ingrese categoria (-1 para terminar): ");
			catIngresada = sc.nextLine();
		}

		// Ingresa categor�a sin repetir al vector catIngresadas[x]
		while(!catIngresada.equals("-1")){
			for(int x=0; x<1000; x++){
				if(catIngresada.equals(categorias[x][1])){
					ingresar=true;
				}
			}
			// Si se encuentra la categor�a en le vector, se omite
			for(int x=0; x<1000;x++){
				if(catIngresada.equals(catIngresadas[x])){
					omitir=true;
				}
			}
			// Si no se encuentra la categor�a, la ingresa al nuevo vector
			if(ingresar==true && omitir==false){
				catIngresadas[pos]=catIngresada;
				pos++;
			}
			ingresar=false;
			omitir=false;
			
			StdOut.print("     Ingrese categoria (-1 para terminar): ");
			catIngresada = sc.nextLine();
			
		}
		
		// Ingresa los codigos en un vector newCodPorCat sin repetir
		int pos2=0;
		omitir=false;
		String codRepetido="";
		for(int x=0;x<pos;x++){
			for( int y=0; y<1000; y++){
				if(catIngresadas[x].equals(categorias[y][1])){
					codRepetido=categorias[y][0];
					for( int z=0; z<1000; z++){
						if(codRepetido.equals(newCodPorCat[z]) && !codRepetido.equals(null)){
							omitir=true;
						}
					}
					if(omitir==false){
						newCodPorCat[pos2]=categorias[y][0];
						pos2++;
					}
					omitir=false;
				}
			}
		}

		// Suma la ganancia de las copias por categor�as ingresadas
		double sumarGanancia=0;
		for(int x=0; x<pos2; x++){
			for( int y=0; y<1000; y++){
				if(newCodPorCat[x].equals(cod[y])){
					sumarGanancia+=gananciaCopia[y];
				}
			}
		}

		// Si no encuentra ningun valor, arroja que no hay datos para esa categoria
		
		if(sumarGanancia==0){
			StdOut.println("\r     No se encontraron datos para la(s) categoria(s) ingresada(s).");
		}
		else{
			System.out.println("\r     La suma total de las ganancias de la(s) categoria(s) ingresada(s) es: $"+Math.round(sumarGanancia)+" aproximadamente.");
			
		}
		
		// Se vacia el vector de categorias ingresadas
		for(int x=0; x<1000; x++){
			catIngresadas[x]=null;
			newCodPorCat[x]=null;
		}

	}
	
	/**
	 * @param cod
	 * @param nom
	 * @param categorias
	 * @param cantVendida
	 * @param nomTopTen
	 * @param cantTopTen
	 * @throws IOException
	 * Resoluci�n del RF3 con los par�metros obtenidos desde el main
	 */
	public static void RF3(String[]cod,String[]nom,String[][]categorias,int[]cantVendida,String[]nomTopTen, int[]cantTopTen) throws IOException{
		boolean existe = false;
		int pos = 0;
		int aux1 = 0;
		String aux2 = "";
		String catIngresada="";
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		StdOut.print("\r     Ingrese nombre de la categoria: ");
		catIngresada = sc.nextLine();
		
		// Busca si la categor�a ingresada existe
		for(int x=0; x<1000;x++){
			if(catIngresada.equals(categorias[x][1])){

				existe = true;
			}
		}

		if(existe==true){
			ArchivoSalida archTopTen = new ArchivoSalida("top-ten-"+catIngresada+".txt");
			// Ingresa el nombre y cantidad top-ten a vectores nuevos

			for(int x=0; x<1000; x++){
				if(catIngresada.equals(categorias[x][1])){
					for(int y=0; y<1000; y++){
						if(categorias[x][0].equals(cod[y])){
							nomTopTen[pos]=nom[y];
							cantTopTen[pos]=cantVendida[y];
							pos++;
						}
					}
				}
			}

			// Ordenamiento del top ten
			for(int x=0; x<pos+1; x++){
				for(int y=x+1; y < pos+1; y++){
					if(cantTopTen[x] < cantTopTen[y]){
						aux1 = cantTopTen[x];
						cantTopTen[x] = cantTopTen[y];
						cantTopTen[y] = aux1;
						aux2 = nomTopTen[x];
						nomTopTen[x] = nomTopTen[y];
						nomTopTen[y] = aux2;
						}
					}
				}

			// Genera el archivo top-ten
			for(int x=0; x<10; x++){
				Registro regSalida = new Registro(2);
				if(nomTopTen[x]!=null){
					regSalida.agregarCampo(nomTopTen[x]);
					regSalida.agregarCampo(cantTopTen[x]);
					archTopTen.writeRegistro(regSalida);
				}
			}
			StdOut.println("\r     Se ha generado el archivo 'top-ten-"+catIngresada+".txt'");
		}
		else{
			StdOut.println("\r     No existe la categoria ingresada. No se ha generado el archivo.");
			existe=false;
		}
		
		// Vacia los vectores, para evitar errores al reingresar otra categoria desde el menu principal.
		for(int x=0; x<1000; x++){
			nomTopTen[x]=null;
			cantTopTen[x]=0;
		}
	}
	
	/**
	 * M�todo para cerrar el programa
	 */
	public static void RF4(){
		StdOut.println("\r     Ha salido con exito.");
		System.exit(0);
	}
	
	/**
	 * M�todo para imprimir un menu por pantalla
	 */
	public static void imprimirMenu(){
		StdOut.println("");
		StdOut.println("    __________________________________________________________________");
		StdOut.println("   |                                                                  |");
		StdOut.println("   |   ----------------------- Tienda Zmart -----------------------   |");
		StdOut.println("   |                                                                  |");
		StdOut.println("   |   1: Desplegar datos y ganancias del juego mas vendido por ano   |");
		StdOut.println("   |   2: Desplegar ganancia total de ventas por categoria            |");
		StdOut.println("   |   3: Generar archivo de salida top-ten-<categoria>               |");
		StdOut.println("   |   4: Salir del programa                                          |");
		StdOut.println("   |                                                                  |");
		StdOut.println("   |__________________________________________________________________|");
		StdOut.println("");
	}

	/**
	 * @param args
	 * @throws IOException
	 * Main donde se ejecutan todos los m�todos anteriores.
	 */
	public static void main(String[] args) throws IOException{
		String []cod = new String[1000];
		String []nom = new String[1000];
		int []ano = new int[1000];
		double []precio = new double[1000];
		double []porcGanancia = new double[1000];
		int []cantVendida = new int[1000];
		String [][] categorias = new String[1000][2];
		double [] gananciaCopia = new double[1000];
		String [] catIngresadas = new String[1000];
		String [] nomTopTen = new String[1000];
		int [] cantTopTen = new int[1000];
		String [] newCodPorCat = new String[1000];
		App.leerArchivos(cod, nom, ano, precio, porcGanancia, cantVendida, categorias);
		App.calcularGananciasPorCopia(gananciaCopia, precio, porcGanancia, cantVendida);
		int opcion = 0;
		
		while(true){
			App.imprimirMenu();
			StdOut.print("     Ingrese una opcion del menu: ");
			opcion = StdIn.readInt();
			while(opcion<1 || opcion>4){
				StdOut.println("     Error, Ingrese una opcion entre 1 y 4.");
				StdOut.println("");
				StdOut.print("     Ingrese una opcion del menu: ");
				opcion = StdIn.readInt();
			}
			switch(opcion){
				case 1:
					App.RF1(ano, nom, cantVendida, gananciaCopia);
					break;
				case 2:
					App.RF2(cod, newCodPorCat, catIngresadas, categorias, gananciaCopia);
					break;
				case 3:
					App.RF3(cod, nom, categorias, cantVendida, nomTopTen, cantTopTen);
					break;
				case 4:
					App.RF4();
					break;
			}
		}
	}
}