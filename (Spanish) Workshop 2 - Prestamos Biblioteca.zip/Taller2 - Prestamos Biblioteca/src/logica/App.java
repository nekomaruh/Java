package logica;
import java.io.IOException;
import dominio.*;
import ucn.*;

/**
 * @author Johan Ordenes / Cecilia Rojas
 * JavaDoc implementado en interface SistemaBibliotecario y clase Prestamos
 * Tildes omitidas al ejecutar el programa
 */

public class App {
	
	public static void leerClientes(SistemaBibliotecario sistema){
		try{
			ArchivoEntrada archClientes = new ArchivoEntrada("clientes.txt");
			while (!archClientes.isEndFile()){
				Registro reg = archClientes.getRegistro();
				String rut = reg.getString();
				String nombre = reg.getString();
				String apellido = reg.getString();
				int num = reg.getInt();
				String correo = reg.getString();
				Cliente cliente = new Cliente(rut,nombre,apellido,num,correo);
				try{
					sistema.ingresarCliente(cliente);
				}
				catch(IllegalArgumentException ex){
					System.out.println(ex.getMessage());
				}
			}
		}catch(IOException ex){
			System.out.println("No se pudo leer el archivo 'clientes.txt'");
		}
	}
	
	public static void leerLibros(SistemaBibliotecario sistema){
		try{
			ArchivoEntrada archLibros = new ArchivoEntrada("libros.txt");
			while (!archLibros.isEndFile()){
				Registro reg = archLibros.getRegistro();
				String isbn = reg.getString();
				String titulo = reg.getString();
				String autor = reg.getString();
				int ano = reg.getInt();
				Libro libro = new Libro(isbn,titulo,autor,ano);
				try{
					sistema.ingresarLibro(libro);
				}
				catch(IllegalArgumentException ex){
					System.out.println(ex.getMessage());
				}
			}
		}
		catch(IOException ex){
			System.out.println("No se pudo leer el archivo 'libros.txt'");
		}
	}
	
	public static void leerPrestamos(SistemaBibliotecario sistema){
		try{
			ArchivoEntrada archPrestamos = new ArchivoEntrada("prestamos.txt");
			while (!archPrestamos.isEndFile()){
				Registro reg = archPrestamos.getRegistro();
				int codigo = reg.getInt();
				String rut = reg.getString();
				String libroPedidoISBN = reg.getString();
				String fechaPrestamo = reg.getString();
				String fechaDevEst = reg.getString();
				String fechaDevReal = reg.getString();
				Prestamo prestamo = new Prestamo(codigo,rut,libroPedidoISBN,fechaPrestamo,fechaDevEst,fechaDevReal);
				try{
					sistema.ingresarPrestamo(prestamo);
				}
				catch(IllegalArgumentException ex){
					System.out.println(ex.getMessage());
				}
			}
		}
		catch(IOException ex){
			System.out.println("No se pudo leer el archivo 'prestamos.txt'");
		}
	}
	
	public static void menu(SistemaBibliotecario sistema){
		while(true){
			sistema.generarMenuDeOpciones();
			String opcion = StdIn.readString();			
			
			switch(opcion){
				case "1":
					String rut;
					System.out.print("Ingrese rut: ");
					rut = StdIn.readString();
					try{
						sistema.desplegarDeudaClientes(rut);
					}catch(IllegalArgumentException ex){
						System.out.println(ex.getMessage());
					}
					break;
				case "2":
					String fecha1;
					String fecha2;
					System.out.print("Ingrese fecha inicial (dd-mm-aa): ");
					fecha1 = StdIn.readString();
					System.out.print("Ingrese fecha final (dd-mm-aa): ");
					fecha2 = StdIn.readString();
					try{
						sistema.desplegarLibroMasSolicitado(fecha1, fecha2);
					}catch(IllegalArgumentException ex){
						System.out.println(ex.getMessage());
					}
					break;
				case "3":
					sistema.generarArchivoDevolucionesPendientes();
					break;
				case "4":
					System.out.println("Ha salido con exito.");
					System.exit(0);
					break;
					
				default:
					try{
						int numero = Integer.parseInt(opcion);
						if(numero<1 || numero>4){
							throw new IllegalArgumentException("Error");
						}
						
					}catch(IllegalArgumentException ex){
						System.out.println("Opcion no valida.");
					}
				}
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SistemaBibliotecario sistema = new SistemaBibliotecarioImpl();
		leerClientes(sistema);
		leerLibros(sistema);
		leerPrestamos(sistema);
		sistema.asociar();
		menu(sistema);
	}
}
