package logica;

import java.io.IOException;
import dominio.*;
import ucn.*;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.text.DateFormat;
import java.text.ParseException;
import java.util.Date;

public class SistemaBibliotecarioImpl implements SistemaBibliotecario{
	
	private ListaClientes listaClientes;
	private ListaLibros listaLibros;
	private ListaPrestamos listaPrestamos;

	public SistemaBibliotecarioImpl() {
		this.listaClientes = new ListaClientes(1000);
		this.listaLibros = new ListaLibros(1000);
		this.listaPrestamos = new ListaPrestamos(1000);
	}
	
	@Override
	public void ingresarCliente(Cliente cliente) {
		// TODO Auto-generated method stub
		boolean ingreso = listaClientes.insertarCliente(cliente);
		if(ingreso==false){
			throw new IllegalArgumentException("No se pudo ingresar el Cliente.");
		}
	}

	@Override
	public void ingresarLibro(Libro libro) {
		// TODO Auto-generated method stub
		boolean ingreso = listaLibros.insertarLibro(libro);
		if(ingreso==false){
			throw new IllegalArgumentException("No se pudo ingresar el Libro.");
		}
	}
	
	@Override
	public void ingresarPrestamo(Prestamo prestamo) {
		// TODO Auto-generated method stub
		boolean ingreso = listaPrestamos.insertarPrestamo(prestamo);
		if(ingreso==false){
			throw new IllegalArgumentException("No se pudo ingresar el Prestamo.");
		}

	}
	
	@Override
	public void asociar(){
		int cantPrestamos = listaPrestamos.getCantPrestamos();
		int cantClientes = listaClientes.getCantClientes();
		int cantLibros = listaLibros.getCantLibros();
		
		// Asocia los prestamos con los clientes
		for(int i=0; i<cantClientes; i++){
			Cliente c = listaClientes.getClienteI(i);
			for(int j=0; j<cantPrestamos; j++){
				Prestamo p = listaPrestamos.getPrestamoI(j);
				if(p.getRutCliente().equals(c.getRut())){
					c.getListaPrestamos().insertarPrestamo(p);
					p.setCliente(c);
				}
			}
		}
		
		// Asocia los prestamos con los libros
		for(int i=0; i<cantLibros; i++){
			Libro l = listaLibros.getLibroI(i);
			for(int j=0; j<cantPrestamos; j++){
				Prestamo p = listaPrestamos.getPrestamoI(j);
				if(l.getISBN().equals(p.getLibroPedidoISBN())){
					l.getListaprestamos().insertarPrestamo(p);
					p.setLibro(l);
				}
			}
		}
	}

	@Override
	public void desplegarDeudaClientes(String rut) {
		// TODO Auto-generated method stub
		// RF1
		Cliente c = listaClientes.encontrarCliente(rut);
		if(c==null){
			throw new IllegalArgumentException("No existe cliente asociado para el rut ingresado.");
		}
		int cantPrestamos = c.getListaPrestamos().getCantPrestamos();
		int deudaTotal =0;
		System.out.println("");
		for(int i=0; i<cantPrestamos; i++){
			Prestamo p = c.getListaPrestamos().getPrestamoI(i);
			if(!p.getFechaDevReal().equals("0") && !p.getFechaDevEst().equals(p.getFechaDevReal())){
				System.out.println("Codigo del prestamo: "+ p.getLibroPedidoISBN());
				System.out.println("Fecha del prestamo: "+p.getFechaPrestamo());
				System.out.println("Fecha devoluci�n estimada: "+p.getFechaDevEst());
				System.out.println("Fecha devoluci�n real: "+p.getFechaDevReal());
				System.out.println("Dias pasados (Fecha de devolucion estimada y real): "+p.getDiasFechaEstimadaFechaReal());
				System.out.println("Deuda asociada (Fecha prestamo hasta la devolucion): $"+p.getDeudaFechaPrestamosFechaReal());
				System.out.println("");
				deudaTotal += p.getDeudaFechaPrestamosFechaReal();
			}
		}
		if(deudaTotal!=0){
			System.out.println("Deuda Total: $"+deudaTotal);
		}
		else{
			System.out.println("El cliente no presenta deudas.");
		}

	}

	@Override
	public void desplegarLibroMasSolicitado(String fecha1, String fecha2) {
		// TODO Auto-generated method stub
		// RF2
		int cantPrestamos = listaPrestamos.getCantPrestamos();
		String fecha3;
		
		DateFormat f = DateFormat.getDateInstance(DateFormat.SHORT);
		
		String [] vRango = new String[1000];
		int pos=0;
		
		try {
			Date fechaIngresada1 = f.parse(fecha1);
			Date fechaIngresada2 = f.parse(fecha2);
			
			Calendar cal1 = new GregorianCalendar();
			Calendar cal2 = new GregorianCalendar();
			Calendar cal3 = new GregorianCalendar();
			
			cal1.setTime(fechaIngresada1);
			cal2.setTime(fechaIngresada2);
			
			for(int i=0; i<cantPrestamos; i++){
				Prestamo p = listaPrestamos.getPrestamoI(i);
				fecha3 = p.getFechaPrestamo();
				Date fechaPrestamo = f.parse(fecha3);
				cal3.setTime(fechaPrestamo);
				
				if(cal3.after(cal1) && cal3.before(cal2)){
					vRango[pos]=p.getLibro().getISBN();
					pos++;
				}
			}
			
			// Busca el codigo del libro mas solicitado
			int frecuenciaMax=0;
			String moda = null;
			int frecuencia = 0;
			for(int i=0; i<pos; i++){
				frecuencia=0;
				for( int j=0; j<pos; j++){
					if(vRango[i].equals(vRango[j])){
						frecuencia++;
					}
					if(frecuencia>frecuenciaMax){
						moda = vRango[i];
						frecuenciaMax=frecuencia;
					}
				}
			}
			if(moda==null){
				throw new IllegalArgumentException("Fecha ingresada erronea, no hay datos asociados a la fecha ingresada.");
			}
			
			Libro l = listaLibros.encontrarLibro(moda);
			System.out.println("");
			System.out.println("El libro mas solicitado es:");
			System.out.println(" - ISBN: "+moda);
			System.out.println(" - Titulo: "+ l.getTitulo());
			System.out.println(" - Autor: "+l.getAutor());
			System.out.println(" - Ano de publicacion: "+l.getAnoLanzamiento());
			System.out.println(" - Cantidad de veces solicitado: "+frecuencia);
			
			
		} catch (ParseException e) {
			System.out.println("No se encontraron datos para la fecha ingresada.");
		}
		
	}

	@Override
	public void generarArchivoDevolucionesPendientes() {
		// TODO Auto-generated method stub
		// RF3
		int cantPrestamos = listaPrestamos.getCantPrestamos();
		int pos=0;
		
		int []vCodPre = new int[1000];
		String [] vFechaP = new String[1000];
		String [] vDevEst = new String[1000];
		String [] vApeCli = new String[1000];
		String [] vNomCli = new String[1000];
		int [] vNumCli = new int[1000];
		String [] vCorCli = new String[1000];
		String [] vNomLib = new String [1000];
		
		int [] vDias = new int[1000];
		int [] vMeses = new int[1000];
		int [] vAno = new int[1000];
		
		for(int i=0; i<cantPrestamos; i++){
			Prestamo p = listaPrestamos.getPrestamoI(i);
			if(p.getFechaDevReal().equals("0")){
				int codigo = p.getCodigo();
				String fechaPrestamo = p.getFechaPrestamo();
				String fechaDevEst = p.getFechaDevEst();
				String apeCliente = p.getCliente().getApellido();
				String nomCliente = p.getCliente().getNombre();
				int numCliente = p.getCliente().getCelular();
				String corCliente = p.getCliente().getCorreo();
				String nomLibro = p.getLibro().getTitulo();
				
				vCodPre[pos]= codigo;
				vFechaP[pos]=fechaPrestamo;
				vDevEst[pos]=fechaDevEst;
				vApeCli[pos]=apeCliente;
				vNomCli[pos]=nomCliente;
				vNumCli[pos]=numCliente;
				vCorCli[pos]=corCliente;
				vNomLib[pos]=nomLibro;
				
				String fecha = fechaDevEst;
				
				String[] vFechaIni = fecha.split("-");
				Integer dia1 = Integer.parseInt(vFechaIni[0]);
				Integer mes1 = Integer.parseInt(vFechaIni[1]);
				Integer ano1 = Integer.parseInt(vFechaIni[2]);
				
				vDias[pos] = dia1;
				vMeses[pos] = mes1;
				vAno[pos] = ano1;
				
				pos++;
			}
		}
		
		int auxCodPre;
		String auxFechaP;
		String auxDevEst;
		String auxApeCli;
		String auxNomCli;
		int auxNumCli;
		String auxCorCli;
		String auxNomLib;
		
		int auxAno;
		int auxMes;
		int auxDia;
		
		// Ordenamiento de burbuja
		for(int x=0; x<=pos-2; x++){
			for(int y=pos-1; y>=x+1; y--){
				if (vDias[y]<vDias[y-1]){
					auxDia=vDias[y];
					auxMes=vMeses[y];
					auxAno=vAno[y];
					auxCodPre = vCodPre[y];
					auxFechaP = vFechaP[y];
					auxDevEst = vDevEst[y];
					auxApeCli = vApeCli[y];
					auxNomCli = vNomCli[y];
					auxNumCli = vNumCli[y];
					auxCorCli = vCorCli[y];
					auxNomLib = vNomLib[y];
					vDias[y]=vDias[y-1];
					vMeses[y]=vMeses[y-1];
					vAno[y]=vAno[y-1];
					vCodPre[y]=vCodPre[y-1];
					vFechaP[y]=vFechaP[y-1];
					vDevEst[y]=vDevEst[y-1];
					vApeCli[y]=vApeCli[y-1];
					vNomCli[y]=vNomCli[y-1];
					vNumCli[y]=vNumCli[y-1];
					vCorCli[y]=vCorCli[y-1];
					vNomLib[y]=vNomLib[y-1];
					vDias[y-1]=auxDia;	
					vMeses[y-1]=auxMes;
					vAno[y-1]=auxAno;
					vCodPre[y-1]=auxCodPre;
					vFechaP[y-1]=auxFechaP;
					vDevEst[y-1]=auxDevEst;
					vApeCli[y-1]=auxApeCli;
					vNomCli[y-1]=auxNomCli;
					vNumCli[y-1]=auxNumCli;
					vCorCli[y-1]=auxCorCli;
					vNomLib[y-1]=auxNomLib;
					}
				}
			}
		
		for(int x=0; x<=pos-2; x++){
			for(int y=pos-1; y>=x+1; y--){
				if (vMeses[y]<vMeses[y-1]){
					auxDia=vDias[y];
					auxMes=vMeses[y];
					auxAno=vAno[y];
					auxCodPre = vCodPre[y];
					auxFechaP = vFechaP[y];
					auxDevEst = vDevEst[y];
					auxApeCli = vApeCli[y];
					auxNomCli = vNomCli[y];
					auxNumCli = vNumCli[y];
					auxCorCli = vCorCli[y];
					auxNomLib = vNomLib[y];
					vDias[y]=vDias[y-1];
					vMeses[y]=vMeses[y-1];
					vAno[y]=vAno[y-1];
					vCodPre[y]=vCodPre[y-1];
					vFechaP[y]=vFechaP[y-1];
					vDevEst[y]=vDevEst[y-1];
					vApeCli[y]=vApeCli[y-1];
					vNomCli[y]=vNomCli[y-1];
					vNumCli[y]=vNumCli[y-1];
					vCorCli[y]=vCorCli[y-1];
					vNomLib[y]=vNomLib[y-1];
					vDias[y-1]=auxDia;	
					vMeses[y-1]=auxMes;
					vAno[y-1]=auxAno;
					vCodPre[y-1]=auxCodPre;
					vFechaP[y-1]=auxFechaP;
					vDevEst[y-1]=auxDevEst;
					vApeCli[y-1]=auxApeCli;
					vNomCli[y-1]=auxNomCli;
					vNumCli[y-1]=auxNumCli;
					vCorCli[y-1]=auxCorCli;
					vNomLib[y-1]=auxNomLib;
					}
				}
			}
		
		for(int x=0; x<=pos-2; x++){
			for(int y=pos-1; y>=x+1; y--){
				if (vAno[y]<vAno[y-1]){
					auxDia=vDias[y];
					auxMes=vMeses[y];
					auxAno=vAno[y];
					auxCodPre = vCodPre[y];
					auxFechaP = vFechaP[y];
					auxDevEst = vDevEst[y];
					auxApeCli = vApeCli[y];
					auxNomCli = vNomCli[y];
					auxNumCli = vNumCli[y];
					auxCorCli = vCorCli[y];
					auxNomLib = vNomLib[y];
					vDias[y]=vDias[y-1];
					vMeses[y]=vMeses[y-1];
					vAno[y]=vAno[y-1];
					vCodPre[y]=vCodPre[y-1];
					vFechaP[y]=vFechaP[y-1];
					vDevEst[y]=vDevEst[y-1];
					vApeCli[y]=vApeCli[y-1];
					vNomCli[y]=vNomCli[y-1];
					vNumCli[y]=vNumCli[y-1];
					vCorCli[y]=vCorCli[y-1];
					vNomLib[y]=vNomLib[y-1];
					vDias[y-1]=auxDia;	
					vMeses[y-1]=auxMes;
					vAno[y-1]=auxAno;
					vCodPre[y-1]=auxCodPre;
					vFechaP[y-1]=auxFechaP;
					vDevEst[y-1]=auxDevEst;
					vApeCli[y-1]=auxApeCli;
					vNomCli[y-1]=auxNomCli;
					vNumCli[y-1]=auxNumCli;
					vCorCli[y-1]=auxCorCli;
					vNomLib[y-1]=auxNomLib;
					}
				}
			}

		try {
			ArchivoSalida archSalida = new ArchivoSalida("devoluciones_pendientes.txt");
			for (int i = 0; i < pos; i++) {
				Registro reg = new Registro(7);
				reg.agregarCampo(vCodPre[i]);
				reg.agregarCampo(vFechaP[i]);
				reg.agregarCampo(vDevEst[i]);
				reg.agregarCampo(vApeCli[i]);
				reg.agregarCampo(vNomCli[i]);
				reg.agregarCampo(vNumCli[i]+" "+vCorCli[i]);
				reg.agregarCampo(vNomLib[i]);
				archSalida.writeRegistro(reg);
			}
		} catch (IOException e) {
			System.out.println("No se ha podido generar el archivo.");
		}
		System.out.println("Se ha generado el archivo correctamente.");
		
	}

	@Override
	public void generarMenuDeOpciones() {
		// TODO Auto-generated method stub
		// RF4
		System.out.println("_______________________________________________________");
		System.out.println("                                                       ");
		System.out.println("      ---------- Sistema de Biblioteca ----------      ");
		System.out.println("                                                       ");
		System.out.println("   (1) Obtener deudas por Cliente y deuda Total        ");
		System.out.println("   (2) Obtener datos del libro con mas demandas        ");
		System.out.println("   (3) Generar archivo 'devoluciones_pendientes.txt'   ");
		System.out.println("   (4) Salir del programa                              ");
		System.out.println("_______________________________________________________");
		System.out.println("");
		System.out.print(("Ingrese una opcion del menu: "));

	}	

}
