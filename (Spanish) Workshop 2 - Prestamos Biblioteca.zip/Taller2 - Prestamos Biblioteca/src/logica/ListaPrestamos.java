package logica;
import dominio.Prestamo;

public class ListaPrestamos {
	private int max;
	private int cantPrestamos;
	private Prestamo [] listaPrestamos;
	
	public ListaPrestamos(int max) {
		this.max = max;
		this.cantPrestamos = 0;
		this.listaPrestamos = new Prestamo[max];
	}
	
	public Prestamo encontrarPrestamo(String rutCliente){
		int i=0;
		for(i=0; i<cantPrestamos;i++){
			if(listaPrestamos[i].getRutCliente().equals(rutCliente)){
				break;
			}
		}
		if (i==cantPrestamos){
			return null;
		}
		
		else{
			return listaPrestamos[i];
		}
	}
	
	public boolean insertarPrestamo(Prestamo prestamo){
		if(cantPrestamos<max){
			listaPrestamos[cantPrestamos]=prestamo;
			cantPrestamos++;
			return true;
		}
		else{
			return false;
		}
	}

	public int getCantPrestamos() {
		return cantPrestamos;
	}
	
	public Prestamo getPrestamoI(int i){
		if(i>=0 && i<cantPrestamos){
			return listaPrestamos[i];
		}
		else{
			return null;
		}
	}
	
	

}
