package logica;
import dominio.Libro;

public class ListaLibros {
	private int max;
	private int cantLibros;
	private Libro[] listaLibros;
	
	public ListaLibros(int max) {
		this.max = max;
		this.cantLibros = 0;
		this.listaLibros = new Libro[max];
	}
	
	public Libro encontrarLibro(String isbn){
		int i=0;
		for(i=0; i<cantLibros;i++){
			if(listaLibros[i].getISBN().equals(isbn)){
				break;
			}
		}
		if (i==cantLibros){
			return null;
		}
		
		else{
			return listaLibros[i];
		}
	}
	
	public boolean insertarLibro(Libro libro){
		if(cantLibros<max){
			listaLibros[cantLibros]=libro;
			cantLibros++;
			return true;
		}
		else{
			return false;
		}
	}

	public int getCantLibros() {
		return cantLibros;
	}
	
	public Libro getLibroI(int i){
		if(i>=0 && i<cantLibros){
			return listaLibros[i];
		}
		else{
			return null;
		}
	}
}

