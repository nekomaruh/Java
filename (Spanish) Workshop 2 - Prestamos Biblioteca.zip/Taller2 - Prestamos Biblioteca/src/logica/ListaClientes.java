package logica;
import dominio.Cliente;

public class ListaClientes {
	private int max;
	private int cantClientes;
	private Cliente [] listaClientes;
	
	public ListaClientes(int max) {
		this.max = max;
		this.cantClientes = 0;
		this.listaClientes = new Cliente[max];
	}
	
	public Cliente encontrarCliente(String rut){
		int i=0;
		for(i=0; i<cantClientes;i++){
			if(listaClientes[i].getRut().equals(rut)){
				break;
			}
		}
		if (i==cantClientes){
			return null;
		}
		
		else{
			return listaClientes[i];
		}
	}
	
	public boolean insertarCliente(Cliente cliente){
		if(cantClientes<max){
			listaClientes[cantClientes]=cliente;
			cantClientes++;
			return true;
		}
		else{
			return false;
		}
	}

	public int getCantClientes() {
		return cantClientes;
	}
	
	public Cliente getClienteI(int i){
		if(i>=0 && i<cantClientes){
			return listaClientes[i];
		}
		else{
			return null;
		}
	}
	
}
