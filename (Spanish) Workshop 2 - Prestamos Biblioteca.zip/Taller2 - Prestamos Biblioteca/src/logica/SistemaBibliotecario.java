package logica;

import dominio.*;

public interface SistemaBibliotecario {
	
	/**
	 * @param cliente
	 * Ingresa los clientes al contenedor general de
	 * ListaClientes
	 */
	public void ingresarCliente(Cliente cliente);
	
	/**
	 * @param libro
	 * Ingresa los libros al contenedor general de
	 * ListaLibros
	 */
	public void ingresarLibro(Libro libro);
	
	/**
	 * @param prestamo
	 * Ingresa los prestamos al contenedor general de
	 * ListaPrestamos
	 */
	public void ingresarPrestamo(Prestamo prestamo);
	
	/**
	 * Asocia las clases Clientes con ListaPrestamos
	 * Asocia las clases Libros con ListaLibros
	 * Asocia las clases Prestamo con Cliente
	 * Asocia las clases Prestamo con Libro
	 */
	public void asociar();
	
	/**
	 * @param rut
	 * Despliega los datos de los clientes, el prestamo, 
	 * fecha de prestamo, fecha de devolucion estimada, 
	 * fecha de devolucion real, dias pasados, y su deuda 
	 * asociada.
	 * Adem�s se despliega la deuda total de todos los 
	 * pr�stamos que ha devuelto fuera de tiempo.
	 */
	public void desplegarDeudaClientes(String rut);
	/**
	 * @param fecha1
	 * @param fecha2
	 * Despliega los datos del libro m�s solicitado seg�n 
	 * las fechas ingresadas.
	 */
	public void desplegarLibroMasSolicitado(String fecha1, String fecha2);
	/**
	 * Genera un archivo que muestra los datos de los 
	 * libros que aun no se han devuelto, junto a los 
	 * datos de su cliente asociado.
	 * Estos datos se encuentran ordenados por fecha
	 * de devoluci�n estimada, desde la fecha m�s 
	 * antigua a la m�s reciente.
	 */
	public void generarArchivoDevolucionesPendientes();
	/**
	 * Imprime un menu de opciones de 1 a 4 para responder 
	 * a los requisitos funcionales del programa.
	 */
	public void generarMenuDeOpciones();

}
