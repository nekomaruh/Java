package dominio;
import logica.ListaPrestamos;

public class Libro {
	private String isbn;
	private String titulo;
	private String autor;
	private int anoLanzamiento;
	private ListaPrestamos listaprestamos;
	
	public Libro(String isbn, String titulo, String autor, int anoLanzamiento) {
		this.isbn = isbn;
		this.titulo = titulo;
		this.autor = autor;
		this.anoLanzamiento = anoLanzamiento;
		this.listaprestamos = new ListaPrestamos(1000);
	}

	public String getISBN() {
		return isbn;
	}

	public void setISBN(String iSBN) {
		isbn = iSBN;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getAutor() {
		return autor;
	}

	public void setAutor(String autor) {
		this.autor = autor;
	}

	public int getAnoLanzamiento() {
		return anoLanzamiento;
	}

	public void setAnoLanzamiento(int anoLanzamiento) {
		this.anoLanzamiento = anoLanzamiento;
	}

	public ListaPrestamos getListaprestamos() {
		return listaprestamos;
	}

	public void setListaprestamos(ListaPrestamos listaprestamos) {
		this.listaprestamos = listaprestamos;
	}

}
