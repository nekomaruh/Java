package dominio;

public class Prestamo {
	private int codigo;
	private String rutCliente;
	private String libroPedidoISBN;
	private String fechaPrestamo;
	private String fechaDevEst;
	private String fechaDevReal;
	private Cliente cliente;
	private Libro libro;
	
	public Prestamo(int codigo, String rutCliente, String libroPedidoISBN, String fechaPrestamo, String fechaDevEst,
			String fechaDevReal) {
		this.codigo = codigo;
		this.rutCliente = rutCliente;
		this.libroPedidoISBN = libroPedidoISBN;
		this.fechaPrestamo = fechaPrestamo;
		this.fechaDevEst = fechaDevEst;
		this.fechaDevReal = fechaDevReal;
		this.cliente = null;
		this.libro = null;
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public String getRutCliente() {
		return rutCliente;
	}

	public void setRutCliente(String rutCliente) {
		this.rutCliente = rutCliente;
	}

	public String getLibroPedidoISBN() {
		return libroPedidoISBN;
	}

	public void setLibroPedidoISBN(String libroPedidoISBN) {
		this.libroPedidoISBN = libroPedidoISBN;
	}

	public String getFechaPrestamo() {
		return fechaPrestamo;
	}

	public void setFechaPrestamo(String fechaPrestamo) {
		this.fechaPrestamo = fechaPrestamo;
	}

	public String getFechaDevEst() {
		return fechaDevEst;
	}

	public void setFechaDevEst(String fechaDevEst) {
		this.fechaDevEst = fechaDevEst;
	}

	public String getFechaDevReal() {
		return fechaDevReal;
	}

	public void setFechaDevReal(String fechaDevReal) {
		this.fechaDevReal = fechaDevReal;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}
	
	public Libro getLibro() {
		return libro;
	}

	public void setLibro(Libro libro) {
		this.libro = libro;
	}
	
	/**
	 * @param f1
	 * @param f2
	 * @return Dias
	 * Calcula los dias que han pasado entre 2 fechas 
	 * ingresadas por paramentros.
	 */
	public int calcularDiasEntreFechas(String f1, String f2){
		int [] dias = {31,28,31,30,31,30,31,31,30,31,30,31};
		String [] fechaI = f1.split("-");
        String [] fechaF = f2.split("-");
        int diaI = Integer.parseInt(fechaI[0]);
        int mesI = Integer.parseInt(fechaI[1]);
        int anoI = Integer.parseInt(fechaI[2]);
        int diaF = Integer.parseInt(fechaF[0]);
        int mesF = Integer.parseInt(fechaF[1]);
        int anoF = Integer.parseInt(fechaF[2]);
        int sumadorDias =0;
        int sumadorMesInicial =0, sumadorMesFinal=0;
        int valorAbsoluto =0;
        if( anoI != anoF) {
            valorAbsoluto = anoI-anoF;
            sumadorDias += valorAbsoluto*365;
        }
        if( mesI != mesF) {
            for(int i=0;i<mesI-1;i++) sumadorMesInicial += dias[i];
            for(int i=0; i<mesF-1; i++) sumadorMesFinal += dias[i];
            valorAbsoluto = Math.abs(sumadorMesInicial- sumadorMesFinal);
            sumadorDias += valorAbsoluto;
            
        }
        if(diaI != diaF ){
            valorAbsoluto = Math.abs(diaI-diaF);
            sumadorDias += valorAbsoluto;
        }
        return Math.abs(sumadorDias);

	}

	/**
	 * @return Deuda
	 * Obtiene la deuda entre la fecha de prestamo y
	 * la fecha de devolicion real del libro prestado.
	 */
	public double getDeudaFechaPrestamosFechaReal(){

		double diasPasados = calcularDiasEntreFechas(this.fechaPrestamo,this.fechaDevReal);
		if (diasPasados==0){
			return 0;
		}
		
		// Calcula la deuda de los dias que han pasado
		double deuda = 0;

		if(diasPasados>=1 && diasPasados<=7){
			deuda = diasPasados*100;
		}else{
			if(diasPasados>=8 && diasPasados<=14){
					deuda = diasPasados*300;
				}else{
					if(diasPasados>=15){
						deuda = diasPasados*700;
					}
				}
			}
		return deuda;
	}
	
	/**
	 * @return Dias
	 * Calcula los dias que han transcurrido entre
	 * la fecha de devoluci�n estimada y la fecha de
	 * devoluci�n real.
	 */
	public int getDiasFechaEstimadaFechaReal(){
		
		int diasPasados = calcularDiasEntreFechas(this.fechaDevEst,this.fechaDevReal);
		if (diasPasados==0){
			return 0;
		}
		else{
			return diasPasados;
		}

	}
	
	/**
	 * @return Dias
	 * Calcula los dias que han transcurrido entre la
	 * fecha de prestamo y la fecha de devolucion real.
	 */
	public int getDiasPasadosFechaPrestamoFechaReal(){
		
		int diasPasados = calcularDiasEntreFechas(this.fechaPrestamo,this.fechaDevReal);
		if (diasPasados==0){
			return 0;
		}
		else{
			return diasPasados;
		}
		
	}
	
}
