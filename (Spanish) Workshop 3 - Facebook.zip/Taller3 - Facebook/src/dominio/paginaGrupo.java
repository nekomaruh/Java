package dominio;
import logica.*;

public abstract class paginaGrupo {
	protected int codigo;
	protected String nombre;
	protected String fechaCreacion;
	protected ListaUsuarios listaUsuarios;
	protected Usuario creador;
	
	public paginaGrupo(int codigo, String nombre, String fechaCreacion) {
		this.codigo = codigo;
		this.nombre = nombre;
		this.fechaCreacion = fechaCreacion;
		this.listaUsuarios = new ListaUsuarios(1000);
		this.creador = null;
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getFechaCreacion() {
		return fechaCreacion;
	}

	public void setFechaCreacion(String fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}

	public ListaUsuarios getListaUsuarios() {
		return listaUsuarios;
	}

	public void setListaUsuarios(ListaUsuarios listaUsuarios) {
		this.listaUsuarios = listaUsuarios;
	}

	public Usuario getCreador() {
		return creador;
	}

	public void setCreador(Usuario creador) {
		this.creador = creador;
	}
	
	public abstract int factor();
}
	
	
	
	