package dominio;

public class PaginaNegocio extends Pagina{
	private String direccion;
	private String nombreCiudad;
	private String codigoPostal;
	private int telefono;
	
	public PaginaNegocio(int codigo, String nombre, String fechaCreacion, String categoria, String clasificacion,
			String direccion, String nombreCiudad, String codigoPostal, int telefono) {
		super(codigo, nombre, fechaCreacion, categoria, clasificacion);
		this.direccion = direccion;
		this.nombreCiudad = nombreCiudad;
		this.codigoPostal = codigoPostal;
		this.telefono = telefono;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public String getNombreCiudad() {
		return nombreCiudad;
	}

	public void setNombreCiudad(String nombreCiudad) {
		this.nombreCiudad = nombreCiudad;
	}

	public String getCodigoPostal() {
		return codigoPostal;
	}

	public void setCodigoPostal(String codigoPostal) {
		this.codigoPostal = codigoPostal;
	}

	public int getTelefono() {
		return telefono;
	}

	public void setTelefono(int telefono) {
		this.telefono = telefono;
	}
	
}
