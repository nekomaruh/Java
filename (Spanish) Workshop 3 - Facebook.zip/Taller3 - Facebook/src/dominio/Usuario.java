package dominio;
import logica.*;

public class Usuario {
	private String nombres;
	private String apellidos;
	private String eMail;
	private String password;
	private String fechaNacimiento;
	private char sexo;
	private ListaUsuarios listaAmigos;
	private ListaPaginasGrupo paginasGrupo;
	
	public Usuario(String nombres, String apellidos, String eMail, String password, String fechaNacimiento, char sexo) {
		super();
		this.nombres = nombres;
		this.apellidos = apellidos;
		this.eMail = eMail;
		this.password = password;
		this.fechaNacimiento = fechaNacimiento;
		this.sexo = sexo;
		this.listaAmigos = new ListaUsuarios(1000);
		this.paginasGrupo = new ListaPaginasGrupo(1000);
	}

	public String getNombres() {
		return nombres;
	}

	public void setNombres(String nombres) {
		this.nombres = nombres;
	}

	public String getApellidos() {
		return apellidos;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	public String geteMail() {
		return eMail;
	}

	public void seteMail(String eMail) {
		this.eMail = eMail;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getFechaNacimiento() {
		return fechaNacimiento;
	}

	public void setFechaNacimiento(String fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}

	public char getSexo() {
		return sexo;
	}

	public void setSexo(char sexo) {
		this.sexo = sexo;
	}

	public ListaUsuarios getListaAmigos() {
		return listaAmigos;
	}

	public void setListaAmigos(ListaUsuarios listaAmigos) {
		this.listaAmigos = listaAmigos;
	}

	public ListaPaginasGrupo getPaginasGrupo() {
		return paginasGrupo;
	}

	public void setPaginasGrupo(ListaPaginasGrupo paginasGrupo) {
		this.paginasGrupo = paginasGrupo;
	}
	
	
	
	

}
