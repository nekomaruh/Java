package dominio;

public class Pagina extends paginaGrupo{
	protected String categoria;
	protected String clasificacion;
	
	public Pagina(int codigo, String nombre, String fechaCreacion, String categoria, String clasificacion) {
		super(codigo, nombre, fechaCreacion);
		this.categoria = categoria;
		this.clasificacion = clasificacion;
	}

	public String getCategoria() {
		return categoria;
	}

	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}

	public String getClasificacion() {
		return clasificacion;
	}

	public void setClasificacion(String clasificacion) {
		this.clasificacion = clasificacion;
	}

	@Override
	public int factor() {
		int cantUsuariosPagina = super.getListaUsuarios().getCantUsuarios();
		return cantUsuariosPagina;
	}

}
