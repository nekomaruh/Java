package dominio;
import logica.*;

public class Grupo extends paginaGrupo{
	private ListaUsuarios administradores;

	public Grupo(int codigo, String nombre, String fechaCreacion) {
		super(codigo, nombre, fechaCreacion);
		this.administradores = new ListaUsuarios(1000);
	}

	public ListaUsuarios getAdministradores() {
		return administradores;
	}

	public void setAdministradores(ListaUsuarios administradores) {
		this.administradores = administradores;
	}

	@Override
	public int factor() {
		int cantAdministradores = administradores.getCantUsuarios();
		int cantUsuariosGrupo = super.getListaUsuarios().getCantUsuarios();
		return cantAdministradores+cantUsuariosGrupo;
	}
}
