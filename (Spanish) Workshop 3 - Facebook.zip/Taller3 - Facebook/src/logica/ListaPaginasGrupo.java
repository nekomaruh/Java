package logica;
import dominio.paginaGrupo;

public class ListaPaginasGrupo {
	private int max;
	private int cantPaginasGrupo;
	private paginaGrupo [] listaPaginasGrupo;

	public ListaPaginasGrupo(int max) {
		this.max = max;
		this.cantPaginasGrupo = 0;
		this.listaPaginasGrupo = new paginaGrupo[max];
	}

	public int getCantPaginasGrupo() {
		return cantPaginasGrupo;
	}
	
	public paginaGrupo encontrarPaginaGrupo(int id){
		int i=0;
		for(i=0; i<cantPaginasGrupo;i++){
			if(listaPaginasGrupo[i].getCodigo()==id){
				break;
			}
		}
		if (i==cantPaginasGrupo){
			return null;
		}
		
		else{
			return listaPaginasGrupo[i];
		}
	}
	
	public boolean insertarPaginaGrupo(paginaGrupo paginaOGrupo){
		if(cantPaginasGrupo<max){
			listaPaginasGrupo[cantPaginasGrupo]=paginaOGrupo;
			cantPaginasGrupo++;
			return true;
		}
		else{
			return false;
		}
	}
	
	public boolean eliminarPaginaGrupo(int id){
        int i;
        for (i = 0; i < cantPaginasGrupo; i++) {
            if(listaPaginasGrupo[i].getCodigo()==id){
                break;
            }
        }
        if(i==cantPaginasGrupo){
            return false;
        }
        else{
            for (int j = i; j < cantPaginasGrupo-1; j++) {
                listaPaginasGrupo[j]=listaPaginasGrupo[j+1];
            }
            cantPaginasGrupo--;
            return true;
        }
    }
	
	public paginaGrupo getPaginaGrupoI(int i){
		if(i>=0 && i<cantPaginasGrupo){
			return listaPaginasGrupo[i];
		}
		else{
			return null;
		}
	}

}
