package logica;
import dominio.*;

public interface SistemaFacebook {

	/**
	 * @return Obtiene la lista de los usuarios del sistema.
	 */
	public ListaUsuarios getListaUsuarios(); // Extra
	
	/**
	 * @param u
	 * @return Ingresa el usuario al sistema.
	 */
	public boolean ingresarUsuario(Usuario u); // Lectura de usuarios
	
	
	/**
	 * @param paginaOGrupo
	 * @return Ingresa la pagina o grupo al sistema.
	 */
	public boolean ingresarGrupoOPagina(paginaGrupo paginaOGrupo); // Lectura de paginas o grupos
	 
	/**
	 * @param u
	 * @return Registra el usuario en el sistema.
	 */
	public boolean registrarse(Usuario u); // RF1-A
	
	/**
	 * @param eMail
	 * @param password
	 * @return Inicia sesion con el e-Mail y la contrase�a ingresada.
	 */
	public boolean iniciarSesion(String eMail, String password); // RF1-B
	
	/**
	 * @param eMailAmigo
	 * @return Pregunta por el e-Mail del amigo y lo ingresa al sistema.
	 */
	public boolean agregarAmigos(String eMailAmigo); // RF2-A
	
	/**
	 * @return Muestra la lista de amigos del usuario y el usuario decide si
	 * lo elimina mediante el rut del amigo ingresado por pantalla.
	 */
	public boolean eliminarAmigos(); // RF2-B
	
	/**
	 * @return Muestra los datos correspondientes para la creacion de una
	 * pagina o grupo. Las paginas poseen 4 clasificaciones y los grupos no.
	 */
	public boolean crearPaginaOrGrupo(); // RF2-C
	
	/**
	 * @return Muestra todos los grupos en donde est� unido el usuario.
	 * Luego de mostrar los grupos, el usuario ingresa el codigo del grupo
	 * donde quiere agregar a su amigo. Luego muestra todos los amigos que no
	 * esten en el grupo, y los agrega mediante el e-Mail que el usuario ingresa
	 * por pantalla.
	 */
	public boolean agregarAmigoToGrupo(); // RF2-D
	
	/**
	 * @return Muestra todas las paginas del sistema, independiente de si el
	 * usuario pertenece a ellas o no. El usuario decide por el codigo de una
	 * pagina que se encuentra por pantalla y se une.
	 */
	public boolean buscarPaginaAndUnirse(); // RF2-E
	
	/**
	 * @return Muestra todos las paginas y grupos donde se encuentra el usuario.
	 * El usuario decide cual pagina o grupo salirse mediante el codigo de
	 * pagina o grupo ingresado por pantalla.
	 */
	public boolean salirDeUnaPaginaOrGrupo(); // RF2-F
	
	/**
	 * Muestra el puntaje del usuario, este puntaje depende del factor grupo, y
	 * el factor pagina. El factor pagina es la cantidad de usuarios que posee 
	 * una pagina, y el factor grupo es la cantidad de usuarios y administradores
	 * que posee una un grupo, si el usuario es administrador y estaen un grupo, 
	 * se le a�ade un puntaje extra.
	 */
	public void verPuntajeUsuario(); // RF2-G
	
	/**
	 * @return Cierra la sesion del usuario. Pregunta si desea salir o no.
	 */
	public boolean cerrarSesion();// RF2-H
	
	/**
	 * Lee todos los datos obtenidos desde archivos ".txt" al compilar el 
	 * programa y los ingresa al sistema.
	 */
	public void readDataInformation();// RF3
	
	/**
	 * Guarda todos los datos en archivos ".txt" al salir de la aplicaci�n.
	 */
	public void saveDataInformation();// RF3
}

