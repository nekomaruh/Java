package logica;

import dominio.*;

public class ListaUsuarios {
	private int max;
	private int cantUsuarios;
	private Usuario[] listaUsuarios;
	
	public ListaUsuarios(int max) {
		this.max = max;
		this.cantUsuarios = 0;
		this.listaUsuarios = new Usuario[max];
	}

	public int getCantUsuarios() {
		return cantUsuarios;
	}
	
	public Usuario encontrarUsuarioPassword(String password){
		int i=0;
		for(i=0; i<cantUsuarios;i++){
			if(listaUsuarios[i].getPassword().equals(password)){
				break;
			}
		}
		if (i==cantUsuarios){
			return null;
		}
		
		else{
			return listaUsuarios[i];
		}
	}
	
	public Usuario encontrarUsuarioMail(String eMail){
		int i=0;
		for(i=0; i<cantUsuarios;i++){
			if(listaUsuarios[i].geteMail().equals(eMail)){
				break;
			}
		}
		if (i==cantUsuarios){
			return null;
		}
		
		else{
			return listaUsuarios[i];
		}
	}
	
	public Usuario encontrarUsuarioNombre(String nombre){
		int i=0;
		for(i=0; i<cantUsuarios;i++){
			if(listaUsuarios[i].getNombres().equals(nombre)){
				break;
			}
		}
		if (i==cantUsuarios){
			return null;
		}
		
		else{
			return listaUsuarios[i];
		}
	}
	
	public boolean insertarUsuario(Usuario u){
		if(cantUsuarios<max){
			listaUsuarios[cantUsuarios]=u;
			cantUsuarios++;
			return true;
		}
		else{
			return false;
		}
	}
	
	public boolean eliminarUsuario(String eMail){
        int i;
        for (i = 0; i < cantUsuarios; i++) {
            if(listaUsuarios[i].geteMail().equals(eMail)){
                break;
            }
        }
        if(i==cantUsuarios){
            return false;
        }
        else{
            for (int j = i; j < cantUsuarios-1; j++) {
                listaUsuarios[j]=listaUsuarios[j+1];
            }
            cantUsuarios--;
            return true;
        }
    }
	
	public Usuario getUsuarioI(int i){
		if(i>=0 && i<cantUsuarios){
			return listaUsuarios[i];
		}
		else{
			return null;
		}
	}

}
