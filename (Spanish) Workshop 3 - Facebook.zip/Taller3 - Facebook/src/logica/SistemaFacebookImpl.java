package logica;
import java.io.IOException;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
import dominio.*;
import ucn.ArchivoEntrada;
import ucn.ArchivoSalida;
import ucn.Registro;
import ucn.StdIn;

public class SistemaFacebookImpl implements SistemaFacebook{
	private Usuario usuario;
	private ListaUsuarios listaUsuarios;
	private ListaPaginasGrupo listaPaginasGrupo;
	
	public SistemaFacebookImpl() {
		this.usuario = null;
		this.listaUsuarios = new ListaUsuarios(1000);
		this.listaPaginasGrupo = new ListaPaginasGrupo(1000);
	}

	@Override
	public ListaUsuarios getListaUsuarios() {
		return this.listaUsuarios;
	}

	@Override
	public boolean ingresarUsuario(Usuario u) {
		boolean insertado = listaUsuarios.insertarUsuario(u);
		if(!insertado){
			throw new IllegalArgumentException("Ha excedido el limite de usuarios. No se pueden ingresar mas.");
		}
		return insertado;
	}

	@Override
	public boolean ingresarGrupoOPagina(paginaGrupo paginaOGrupo) {
		boolean ingresado = listaPaginasGrupo.insertarPaginaGrupo(paginaOGrupo);
		if(!ingresado){
			throw new IllegalArgumentException("Ha excedido el limite de paginas o grupos. No se pueden ingresar mas.");
		}
		return ingresado;
	}

	@Override
	public boolean registrarse(Usuario u) {
		boolean registrado = listaUsuarios.insertarUsuario(u);
		if(!registrado){
			throw new IllegalArgumentException("No se ha podido registrar el usuario.");
		}else{
			System.out.println("Registrado correctamente.");
		}
		return registrado;
	}

	@Override
	public boolean iniciarSesion(String eMail, String password) {
		Usuario userEmail = this.listaUsuarios.encontrarUsuarioMail(eMail);
		Usuario userPassw = this.listaUsuarios.encontrarUsuarioPassword(password);
		if(userEmail==userPassw && userEmail!=null){
			System.out.println("Sesion iniciada!.");
			this.usuario = userEmail;
			return true;
		}else{
			System.out.println("Correo o contrasena invalido.");
			System.out.println();
			return false;
		}
	}

	@Override
	public boolean agregarAmigos(String eMailAmigo) {
		Usuario amigo = this.listaUsuarios.encontrarUsuarioMail(eMailAmigo);
		if(this.usuario==amigo){
			System.out.println("No se puede agregar como amigos al mismo usuario.");
			return false;
		}
		for(int i=0; i<this.usuario.getListaAmigos().getCantUsuarios();i++){
			Usuario agregadoAnteriormente = this.usuario.getListaAmigos().getUsuarioI(i);
			if(amigo==agregadoAnteriormente){
				System.out.println("Amigo ya agregado anteriormente.");
				return false;
			}
		}
		if(amigo==null){
			System.out.println("No existe usuario para e-Mail ingresado.");
			return false;
		}
		else{
			boolean agregado = this.usuario.getListaAmigos().insertarUsuario(amigo);
			boolean add = amigo.getListaAmigos().insertarUsuario(this.usuario);
			if(!agregado && !add){
				throw new IllegalArgumentException("No se pudo agregar amigo.");
			}else{
				System.out.println("Amigo agregado correctamente.");
			}
			return agregado;
		}
	}

	@Override
	public boolean eliminarAmigos() {
		System.out.println(" --- Facebook (Eliminar Amigos) ---");
		System.out.println();
		int cantAmigos = this.usuario.getListaAmigos().getCantUsuarios();
		if(cantAmigos==0){
			System.out.println("No tienes ningun amigo.");
			return false;
		}
		// Imprime la lista de los amigos del usuario
		for(int i=0; i<cantAmigos;i++){
			Usuario amigo = this.usuario.getListaAmigos().getUsuarioI(i);
			System.out.println("Amigo: "+ amigo.getNombres());
			System.out.println("Correo: "+amigo.geteMail());
			System.out.println();
		}
		// Pregunta por cual eliminar
		System.out.print("Ingrese el correo del amigo que desea eliminar: ");
		String eMail = StdIn.readLine();
		// Encuentra al amigo
		Usuario AmigoToEliminar = this.usuario.getListaAmigos().encontrarUsuarioMail(eMail);
		// Si el amigo existe, lo elimina
		if(AmigoToEliminar!=null){
			this.usuario.getListaAmigos().eliminarUsuario(eMail);
			AmigoToEliminar.getListaAmigos().eliminarUsuario(this.usuario.geteMail());
			System.out.println("Amigo eliminado.");
			return true;
		}
		// Si no lo encuentra, no lo elimina
		else{
			System.out.println("No se encontro e-Mail de amigo asociado para eliminar.");
			return false;
		}
	}

	@Override
	public boolean crearPaginaOrGrupo() {
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		System.out.println(" --- Facebook (Crear una pagina o grupo) ---");
		System.out.println(" [1] Crear una pagina");
		System.out.println(" [2] Crear un grupo");
		System.out.println(" [3] Cancelar");
		System.out.println();
		System.out.print("Ingrese una opcion: ");
		String option = sc.nextLine();
		
		while(!option.equals("1") && !option.equals("2") && !option.equals("3")){
			System.out.println("Ingrese una opcion correcta.");
			System.out.println();
			System.out.print("Ingrese una opcion: ");
			option = sc.nextLine();
		}
		
		if(option.equals("3")){
			System.out.println("Cancelado.");
			return false;
		}
		
		char[] elementos={'0','1','2','3','4','5','6','7','8','9'};
		
		char[] conjunto = new char[4];
		for(int i=0;i<4;i++){
			int el = (int)(Math.random()*10);
			conjunto[i] = (char)elementos[el];
			}
		
		// Crea el codigo ID a partir de random
		String idCodeStr = new String(conjunto);
		int idCode = Integer.parseInt(idCodeStr);
		
		// Si existe el codigo anteriormente para otra pagina o grupo, se asigna uno generico nuevamente
		paginaGrupo encontrarPG = this.listaPaginasGrupo.encontrarPaginaGrupo(idCode);
		while(encontrarPG!=null){
			for(int i=0;i<4;i++){
				int el = (int)(Math.random()*10);
				conjunto[i] = (char)elementos[el];
				}
			// Crea el codigo ID a partir de random
			idCodeStr = new String(conjunto);
			idCode = Integer.parseInt(idCodeStr);
			encontrarPG = this.listaPaginasGrupo.encontrarPaginaGrupo(idCode);
		}
		
		System.out.println();
		
		if(option.equals("1")){
			System.out.print("Ingrese el nombre de la pagina: ");
		}
		if(option.equals("2")){
			System.out.print("Ingrese el nombre del grupo: ");
		}
		
		// Transforma los datos leidos a caracteres ASCII para que no haya problemas al leer y guardar.
		String original = "������������������������������������������������������������";
	    String ascii =    "AAAAAAACEEEEIIIIDNOOOOOOUUUUYBaaaaaaaceeeeiiiionoooooouuuuyy";
	    
		String nombre = sc.nextLine().toUpperCase();
		String outNombre = nombre;
		
		for (int i=0; i<original.length(); i++) {
	        outNombre = outNombre.replace(original.charAt(i), ascii.charAt(i));
	    }
		
		while(outNombre.contains(",")){
			System.out.println("Ingrese un nombre sin comas.");
			if(option.equals("1")){
				System.out.print("Ingrese el nombre de la pagina: ");
			}
			if(option.equals("2")){
				System.out.print("Ingrese el nombre del grupo: ");
			}
			nombre = sc.nextLine().toUpperCase();
			outNombre = nombre;
			for (int i=0; i<original.length(); i++) {
		        outNombre = outNombre.replace(original.charAt(i), ascii.charAt(i));
		    }
		}
		
		Date date = new Date();
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		String fCreacion = dateFormat.format(date);

		String categoria;
		
		
		switch(option){
			case "1":
				System.out.println();
				System.out.println(" --- Facebook (Tipo de pagina) ---");
				System.out.println(" [1] Lugar o negocio local");
				System.out.println(" [2] Empresa, organizacion o institucion");
				System.out.println(" [3] Artista, grupo musical o personaje");
				System.out.println(" [4] Entretenimiento");
				System.out.println();
				System.out.print("Ingrese tipo de pagina: ");
				String optionP = sc.nextLine();
				while(!optionP.equals("1") && !optionP.equals("2") && !optionP.equals("3") && !optionP.equals("4")){
					System.out.println("Ingrese una opcion correcta.");
					System.out.println("Ingrese una opcion: ");
					optionP = sc.nextLine();
				}
				int optionPag = Integer.parseInt(optionP);
				
				System.out.print("Categoria: ");
				categoria = sc.nextLine().toUpperCase();
				
				String outCategoria = categoria;
				for (int i=0; i<original.length(); i++) {
			        outCategoria = outCategoria.replace(original.charAt(i), ascii.charAt(i));
			    }
				
				while(outCategoria.contains(",")){
					System.out.println("Ingrese una categoria sin comas.");
					System.out.print("Categoria: ");
					categoria = sc.nextLine().toUpperCase();
					outCategoria = categoria;
					for (int i=0; i<original.length(); i++) {
				        outCategoria = outCategoria.replace(original.charAt(i), ascii.charAt(i));
				    }
				}
				paginaGrupo p;
				
				switch(optionPag){
					case 1:
						System.out.print("Direccion: ");
						String dir = sc.nextLine().toUpperCase();
						String outDir = dir;
						for (int i=0; i<original.length(); i++) {
							outDir = outDir.replace(original.charAt(i), ascii.charAt(i));
						}
						while(outDir.contains(",")){
							System.out.println("Ingrese una direccion sin comas.");
							System.out.print("Direccion: ");
							dir = sc.nextLine().toUpperCase();
							outDir = dir;
							for (int i=0; i<original.length(); i++) {
								outDir = outDir.replace(original.charAt(i), ascii.charAt(i));
							}
						}
						System.out.print("Nombre comuna: ");
						String nomC = sc.nextLine().toUpperCase();
						String outNomC = nomC;
						for (int i=0; i<original.length(); i++) {
							outNomC = outNomC.replace(original.charAt(i), ascii.charAt(i));
						}
						while(outNomC.contains(",")){
							System.out.println("Ingrese una comuna sin comas.");
							System.out.print("Nombre comuna: ");
							nomC = sc.nextLine().toUpperCase();
							outNomC = nomC;
							for (int i=0; i<original.length(); i++) {
								outNomC = outNomC.replace(original.charAt(i), ascii.charAt(i));
							}
						}
						System.out.print("Codigo postal: ");
						String codP = sc.nextLine().toUpperCase();
						String outCodP = codP;
						for (int i=0; i<original.length(); i++) {
							outCodP = outCodP.replace(original.charAt(i), ascii.charAt(i));
						}
						while(outCodP.contains(",")){
							System.out.println("Ingrese un codigo postal sin comas.");
							System.out.print("Codigo postal: ");
							codP = sc.nextLine().toUpperCase();
							outCodP = codP;
							for (int i=0; i<original.length(); i++) {
								outCodP = outCodP.replace(original.charAt(i), ascii.charAt(i));
							}
						}
						System.out.print("Telefono: ");
						String telString = sc.nextLine();
						int tel=0;
						boolean leidoCorrectamente = true;
						try{
							tel = Integer.parseInt(telString);
						}catch(NumberFormatException nfe){
							leidoCorrectamente=false;
						}
						while(!leidoCorrectamente){
							System.out.println("Error al leer el telefono, ingrese solo numeros.");
							System.out.print("Telefono: ");
							telString = sc.nextLine();
							try{
								tel = Integer.parseInt(telString);
								leidoCorrectamente=true;
							}catch(NumberFormatException nfe){
								leidoCorrectamente=false;
							}
						}
						p = new PaginaNegocio(idCode,outNombre,fCreacion,outCategoria,"Lugar/Negocio Local",outDir,outNomC,outCodP,tel);
						this.listaPaginasGrupo.insertarPaginaGrupo(p);
						this.usuario.getPaginasGrupo().insertarPaginaGrupo(p);
						p.getListaUsuarios().insertarUsuario(this.usuario);
						p.setCreador(this.usuario);
						System.out.println("Pagina creada.");
						return true;
					case 2:
						p = new Pagina(idCode,outNombre,fCreacion,outCategoria,"Empresa/Organizacion/Institucion");
						this.listaPaginasGrupo.insertarPaginaGrupo(p);
						this.usuario.getPaginasGrupo().insertarPaginaGrupo(p);
						p.getListaUsuarios().insertarUsuario(this.usuario);
						p.setCreador(this.usuario);
						System.out.println("Pagina creada.");
						return true;
					case 3:
						p = new Pagina(idCode,outNombre,fCreacion,outCategoria,"Artista/Grupo Musical/Personaje");
						this.listaPaginasGrupo.insertarPaginaGrupo(p);
						this.usuario.getPaginasGrupo().insertarPaginaGrupo(p);
						p.getListaUsuarios().insertarUsuario(this.usuario);
						p.setCreador(this.usuario);
						System.out.println("Pagina creada.");
						return true;
					case 4:
						p = new Pagina(idCode,outNombre,fCreacion,outCategoria,"Entretenimiento");
						this.listaPaginasGrupo.insertarPaginaGrupo(p);
						this.usuario.getPaginasGrupo().insertarPaginaGrupo(p);
						p.getListaUsuarios().insertarUsuario(this.usuario);
						p.setCreador(this.usuario);
						System.out.println("Pagina creada.");
						return true;
				}	
			case "2":
				paginaGrupo g = new Grupo(idCode,outNombre,fCreacion);
				this.listaPaginasGrupo.insertarPaginaGrupo(g);
				this.usuario.getPaginasGrupo().insertarPaginaGrupo(g);
				g.setCreador(this.usuario);
				((Grupo)g).getAdministradores().insertarUsuario(this.usuario);
				((Grupo)g).getListaUsuarios().insertarUsuario(this.usuario);
				System.out.println("Grupo creado.");
				return true;
			case "3":
				return false;
		}
		return false;
	}

	@Override
	public boolean agregarAmigoToGrupo() {
		System.out.println(" --- Facebook (Ingresar amigo a un grupo) ---");
		System.out.println();
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		int cantAmigos = this.usuario.getListaAmigos().getCantUsuarios();
		int cantPagGrupo= this.usuario.getPaginasGrupo().getCantPaginasGrupo();
		int cantGrupos=0;
		// Muestra la losta de los grupos disponibles
		for(int i=0; i<cantPagGrupo; i++){
			paginaGrupo pG = this.usuario.getPaginasGrupo().getPaginaGrupoI(i);
			if(pG instanceof Grupo){
				System.out.println("Nombre: "+((Grupo)pG).getNombre());
				System.out.println("Codigo ID: "+((Grupo)pG).getCodigo());
				System.out.println("Fecha creacion: "+((Grupo)pG).getFechaCreacion());
				System.out.println();
				cantGrupos++;
			}
		}
		if(cantGrupos==0){
			System.out.println("No perteneces a ningun grupo.");
			return false;
		}
		if(cantAmigos==0){
			System.out.println("No tienes ningun amigo para ingresar a un grupo.");
			return false;
		}
		System.out.print("Ingrese el codigo ID al grupo que quiera agregar su amigo: ");
		String iDString = sc.nextLine();
		
		int iD =0;
		try{
			iD = Integer.parseInt(iDString);
		}catch(NumberFormatException nfe){
			System.out.println("Error al leer el codigo.");
			return false;
		}
		
		// Busca si existe el grupo con la id ingresada.
		boolean existeGrupo=false;
		for(int i=0; i<cantPagGrupo; i++){
			paginaGrupo pG = this.usuario.getPaginasGrupo().getPaginaGrupoI(i);
			if(pG instanceof Grupo){
				if(pG.getCodigo()==iD){
					existeGrupo=true;
				}
			}
		}
		if(!existeGrupo){
			System.out.println("No existe grupo para la iD ingresada.");
			return false;
		}
		
		System.out.println();
		System.out.println( "--- Facebook (Lista de amigos para ingresar al grupo) ---");
		System.out.println();

		boolean hayAmigos = false;
		
		// Imprime la lista de los amigos que no estan en el grupo
		paginaGrupo pG = this.usuario.getPaginasGrupo().encontrarPaginaGrupo(iD);
		
		for(int i=0; i<cantAmigos; i++){
			Usuario amigo = this.usuario.getListaAmigos().getUsuarioI(i);
			Usuario esta = pG.getListaUsuarios().encontrarUsuarioMail(amigo.geteMail());
			if(esta==null){
				System.out.println("Nombre amigo: "+amigo.getNombres());
				System.out.println("Apellido amigo: "+amigo.getApellidos());
				System.out.println("e-Mail amigo: "+amigo.geteMail());
				hayAmigos=true;
				System.out.println();
			}
		}
		if(hayAmigos==false){
			System.out.println("No tienes amigos para agregar al grupo, o estos ya pertenecen al grupo.");
			return false;
		}
			
		// Pregunta por el email del amigo a agregar al grupo
		System.out.print("Ingrese el e-Mail del amigo a agregar al grupo: ");
		String eMail = sc.nextLine();
		
		Usuario encontrarAmigo = this.usuario.getListaAmigos().encontrarUsuarioMail(eMail);
		if(encontrarAmigo==null){
			System.out.println("No se encontro amigo para el e-Mail ingresado.");
			return false;
		}
		else{	
			// Le agrego el grupo a mi amigo
			Usuario amigo = this.listaUsuarios.encontrarUsuarioMail(eMail);
			amigo.getPaginasGrupo().insertarPaginaGrupo(this.listaPaginasGrupo.encontrarPaginaGrupo(iD));
			
			// Lo agrego como usuario a grupo
			paginaGrupo g = this.listaPaginasGrupo.encontrarPaginaGrupo(iD);
			((Grupo)g).getListaUsuarios().insertarUsuario(this.listaUsuarios.encontrarUsuarioMail(eMail));
			
			System.out.print("Le otorgas permisos de administrador? (s/n): ");
			char permiso = sc.nextLine().toUpperCase().charAt(0);
			while(permiso!='S' && permiso!='N'){
				System.out.println("Ingrese un dato correcto!.");
				System.out.print("Le otorgas permisos de administrador? (s/n): ");
				permiso = sc.nextLine().toUpperCase().charAt(0);
			}
			// Si le doy permisos lo agrego como administrador del grupo
			if(permiso=='S'){
				((Grupo)g).getAdministradores().insertarUsuario(this.listaUsuarios.encontrarUsuarioMail(eMail));
				
			}
			System.out.println("Amigo ingresado.");
			return true;
		}
		
	}

	@Override
	public boolean buscarPaginaAndUnirse() {
		System.out.println(" --- Facebook (Unirse a una pagina) ---");
		System.out.println();
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		int cantPaginasGeneral = this.listaPaginasGrupo.getCantPaginasGrupo();
		
		// Imprime todas las paginas existentes.
		for(int i=0; i<cantPaginasGeneral;i++){
			paginaGrupo pG = this.listaPaginasGrupo.getPaginaGrupoI(i);
			if(pG instanceof Pagina){
				System.out.println("Pagina: "+((Pagina)pG).getNombre());
				System.out.println("Creador: "+((Pagina)pG).getCreador().getNombres());
				System.out.println("Clasificacion: "+((Pagina)pG).getClasificacion());
				System.out.println("Categoria: "+((Pagina)pG).getCategoria());
				System.out.println("Cantidad de usuarios: "+((Pagina)pG).getListaUsuarios().getCantUsuarios());
				System.out.println("Fecha de creacion: "+((Pagina)pG).getFechaCreacion());
				System.out.println("Codigo iD: "+((Pagina)pG).getCodigo());
				paginaGrupo delUsuario = this.usuario.getPaginasGrupo().encontrarPaginaGrupo(((Pagina)pG).getCodigo());
				if(delUsuario!=null){
					System.out.println("Estas unido");
				}else{
					System.out.println("No estas unido");
				}
				System.out.println();
			}
		}
		if(cantPaginasGeneral==0){
			System.out.println("No hay paginas disponibles para unirse.");
			return false;
		}
		System.out.print("Ingrese el codigo de la pagina que desea unirse: ");
		String codString = sc.nextLine();
		int cod = 0;
		
		try{
			cod = Integer.parseInt(codString);
		}catch(NumberFormatException nfe){
			System.out.println("Error al leer el codigo.");
			return false;
		}
		
		boolean esta = false;
		
		// Busca si el usuario esta en la pagina
		for(int i=0; i<cantPaginasGeneral;i++){
			paginaGrupo pG = this.listaPaginasGrupo.getPaginaGrupoI(i);
			if(pG instanceof Pagina){
				if(((Pagina)pG).getCodigo()==cod){
					paginaGrupo delUsuario = this.usuario.getPaginasGrupo().encontrarPaginaGrupo(((Pagina)pG).getCodigo());
					if(delUsuario!=null){
						esta=true;
					}else{
						esta=false;
					}
				}
			}
		}
		
		// Ingresa el usuario a la pagina correspondiente.
		if(esta){
			System.out.println("No puedes ingresar a una pagina que ya perteneces.");
			return false;
		}else{
			paginaGrupo pG = this.listaPaginasGrupo.encontrarPaginaGrupo(cod);
			if(pG!=null){
				this.usuario.getPaginasGrupo().insertarPaginaGrupo(pG);
				System.out.println("Ingresado con exito.");
				return true;
			}
			else{
				System.out.println("No se encontro la pagina para el codigo ingresado.");
				return false;
			}
		}
	}

	@Override
	public boolean salirDeUnaPaginaOrGrupo() {
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		System.out.println(" --- Facebook (Salir de pagina o Grupo) ---");
		System.out.println();
		int cantPaginasGrupoUsuario = this.usuario.getPaginasGrupo().getCantPaginasGrupo();
		int cantPaginasGrupo = this.listaPaginasGrupo.getCantPaginasGrupo();
		
		for(int i=0; i<cantPaginasGrupoUsuario; i++){
			paginaGrupo pG = this.usuario.getPaginasGrupo().getPaginaGrupoI(i);
			if(pG instanceof Pagina){
				System.out.println("Pagina: "+((Pagina)pG).getNombre());
				System.out.println("Creador: "+((Pagina)pG).getCreador().getNombres());
				System.out.println("Clasificacion: "+((Pagina)pG).getClasificacion());
				System.out.println("Categoria: "+((Pagina)pG).getCategoria());
				System.out.println("Cantidad de usuarios: "+((Pagina)pG).getListaUsuarios().getCantUsuarios());
				System.out.println("Fecha de creacion: "+((Pagina)pG).getFechaCreacion());
				System.out.println("Codigo iD: "+((Pagina)pG).getCodigo());
			}
			if(pG instanceof Grupo){
				System.out.println("Grupo: "+((Grupo)pG).getNombre());
				System.out.println("Creador: "+((Grupo)pG).getCreador().getNombres());
				System.out.println("Cantidad de usuarios: "+((Grupo)pG).getListaUsuarios().getCantUsuarios());
				System.out.println("Cantidad de administradores: "+((Grupo)pG).getAdministradores().getCantUsuarios());
				System.out.println("Fecha de creacion: "+((Grupo)pG).getFechaCreacion());
				System.out.println("Codigo iD: "+((Grupo)pG).getCodigo());
			}
			System.out.println();
		}
		
		if(cantPaginasGrupoUsuario==0){
			System.out.println("No perteneces a ningun(a) pagina/grupo.");
			return false;
		}
		
		// Pregunta por el codigo de la pagina a salir
		System.out.print("Ingrese el codigo de la pagina que quiere salir: ");
		String iDcodeString = sc.nextLine();
		
		int iDcode=0;
		
		try{
			iDcode = Integer.parseInt(iDcodeString);
		}catch(NumberFormatException nfe){
			System.out.println("Error al leer el codigo.");
			return false;
		}
		
		// Busca si existe la pagina para el codigo ingresado
		paginaGrupo pGUser = this.usuario.getPaginasGrupo().encontrarPaginaGrupo(iDcode);
		if(pGUser==null){
			System.out.println("No existe pagina asociada al codigo ingresado.");
			return false;
		}
		
		// Busca nuevamente la pagina o grupo y retorna verdadero o falso si sale.
		for(int i=0; i<cantPaginasGrupo; i++){
			paginaGrupo pG = this.listaPaginasGrupo.getPaginaGrupoI(i);
			// Si es una pagina
			if(pG instanceof Pagina){
				if(((Pagina)pG).getCodigo()==iDcode){
					// Si el creador es el mismo usuario, no se puede eliminar
					if(((Pagina)pG).getCreador().equals(this.usuario)){
						System.out.println("No puedes salir de la pagina si eres el creador.");
						return false;
					// Sino, elimina el usuario de la pagina.
					}else{
						this.usuario.getPaginasGrupo().eliminarPaginaGrupo(iDcode);
						((Pagina)pG).getListaUsuarios().eliminarUsuario(this.usuario.geteMail());
						System.out.println("Has salido de la pagina correctamente.");
						return true;
					}
				}
			}
			// Si es un grupo
			if(pG instanceof Grupo){
				if(((Grupo)pG).getCodigo()==iDcode){
					int cantAdministradoresGrupo = ((Grupo)pG).getAdministradores().getCantUsuarios();
					int cantUsuariosGrupo = (((Grupo)pG).getListaUsuarios().getCantUsuarios());
					Usuario administradorAux = (((Grupo)pG).getAdministradores().encontrarUsuarioMail(this.usuario.geteMail()));
					if(administradorAux!=null){
						// Si la cantidad de usuarios es 1, se elimina el grupo
						if(cantUsuariosGrupo==1){
							this.usuario.getPaginasGrupo().eliminarPaginaGrupo(iDcode);
							((Grupo)pG).getListaUsuarios().eliminarUsuario(this.usuario.geteMail());
							this.listaPaginasGrupo.eliminarPaginaGrupo(iDcode);
							System.out.println("Has salido del grupo correctamente.");
							System.out.println("Se ha eliminado el grupo ya que eras el unico usuario.");
							return true;
						}
						else{
							// Si hay mas usuarios y es el unico administrador, 
							// Se asigna un nuevo administrador y se sale del grupo.
							if(cantAdministradoresGrupo==1){
								Usuario nuevoAdmin = ((Grupo)pG).getListaUsuarios().getUsuarioI(i+1);
								if(nuevoAdmin==null){
										nuevoAdmin = ((Grupo)pG).getListaUsuarios().getUsuarioI(i-1);
									}
								((Grupo)pG).getAdministradores().insertarUsuario(nuevoAdmin);
								((Grupo)pG).getAdministradores().eliminarUsuario(this.usuario.geteMail());
								this.usuario.getPaginasGrupo().eliminarPaginaGrupo(iDcode);
								((Grupo)pG).getListaUsuarios().eliminarUsuario(this.usuario.geteMail());
								System.out.println("Se ha asignado un nuevo administrador al grupo aleatoriamente.");
								System.out.println("Has salido del grupo correctamente.");
								return true;
								}
							// Si hay mas de un administrador, directamente se sale del grupo.
							else{
								this.usuario.getPaginasGrupo().eliminarPaginaGrupo(iDcode);
								((Grupo)pG).getListaUsuarios().eliminarUsuario(this.usuario.geteMail());
								
								System.out.println("Has salido del grupo correctamente.");
								return true;
							}
						}
					}else{
						this.usuario.getPaginasGrupo().eliminarPaginaGrupo(iDcode);
						((Grupo)pG).getListaUsuarios().eliminarUsuario(this.usuario.geteMail());
						System.out.println("Has salido del grupo correctamente.");
						return false;
					}
				}
			}
		}
		return false;
	}

	@Override
	public void verPuntajeUsuario() {
		int factorPaginaT=0;
		int factorGrupoT=0;
		int cantPagGruposUsuario=this.usuario.getPaginasGrupo().getCantPaginasGrupo();
		for(int i=0; i<cantPagGruposUsuario; i++){
			paginaGrupo pG = this.usuario.getPaginasGrupo().getPaginaGrupoI(i);
			// Se calcula el factor para una pagina.
			if(pG instanceof Pagina){
				int factorPagina = ((Pagina)pG).factor();
				factorPaginaT+=factorPagina;
			}
			// Se calcula el factor para un grupo, si el administrador
			// Es el usuario, se le asigna 1 punto por cada grupo que administre.
			if(pG instanceof Grupo){
				int factorGrupo = ((Grupo)pG).factor();
				if(((Grupo)pG).getCreador().equals(this.usuario)){
					factorGrupoT++;
				}
				factorGrupoT += factorGrupo;
			}
		}
		DecimalFormat df = new DecimalFormat("#.00");
		double puntaje = ((factorPaginaT*0.7)+(factorGrupoT*0.3));
		if(puntaje<1){
			System.out.println("Puntaje usuario: 0"+df.format(puntaje)+" pts.");
		}else{
			System.out.println("Puntaje usuario: "+df.format(puntaje)+" pts.");
		}
		
	}

	@Override
	public boolean cerrarSesion() {
		System.out.print("Desea cerrar sesion (s/n)?: ");
		String opcion = StdIn.readLine().toUpperCase();
		while(!opcion.equals("S") && !opcion.equals("N")){
			System.out.println("Ingrese una opcion correcta.");
			System.out.print("Desea cerrar sesion (s/n)?: ");
			opcion = StdIn.readLine().toUpperCase();
		}
		if(opcion.equals("S")){
			System.out.println("Sesion cerrada.");
			System.out.println();
			return false; // El online del menu cambia a false
		}
		else{
			return true;
		}
	}

	@Override
	public void readDataInformation() {
		int cantUsuarios = this.listaUsuarios.getCantUsuarios();
		int cantPaginasGrupo = this.listaPaginasGrupo.getCantPaginasGrupo();
		
		// Lee los amigos de todos los usuarios y los ingresa al sistema.
		for(int i=0; i<cantUsuarios; i++){
			try{
				ArchivoEntrada cargarAmigos = new ArchivoEntrada("Amigos-"+this.listaUsuarios.getUsuarioI(i).geteMail()+".txt");
				while(!cargarAmigos.isEndFile()){
					Registro r = cargarAmigos.getRegistro();
					String eMail = r.getString();
					Usuario amigo = this.listaUsuarios.encontrarUsuarioMail(eMail);
					this.listaUsuarios.getUsuarioI(i).getListaAmigos().insertarUsuario(amigo);
				}
			} catch (IOException e) {
				System.out.println("El archivo no tiene datos 'Amigos-Usuario.txt'");
			}
		}
		
		// Lee todas las paginas y grupos de los usuarios, y las ingresa al sistema.
		for(int i=0; i<cantUsuarios; i++){
			try{
				ArchivoEntrada cargarPaginasGrupo = new ArchivoEntrada("PaginasGrupo-"+this.listaUsuarios.getUsuarioI(i).geteMail()+".txt");
				while(!cargarPaginasGrupo.isEndFile()){
					Registro r = cargarPaginasGrupo.getRegistro();
					int iD = r.getInt();
					paginaGrupo pG = this.listaPaginasGrupo.encontrarPaginaGrupo(iD);
					this.listaUsuarios.getUsuarioI(i).getPaginasGrupo().insertarPaginaGrupo(pG);	
				}
			} catch (IOException e) {
				System.out.println("El archivo no tiene datos 'PaginasGrupo-Usuario.txt'");
			}
		}
		
		// Lee todos los usuarios de una pagina
		for(int i=0; i<cantPaginasGrupo; i++){
			paginaGrupo pG = this.listaPaginasGrupo.getPaginaGrupoI(i);
			if(pG instanceof Pagina){
				try{
					ArchivoEntrada cargarUsuariosPagina = new ArchivoEntrada("Usuarios-"+this.listaPaginasGrupo.getPaginaGrupoI(i).getCodigo()+".txt");
					while(!cargarUsuariosPagina.isEndFile()){
						Registro r = cargarUsuariosPagina.getRegistro();
						String eMail = r.getString();
						((Pagina)pG).getListaUsuarios().insertarUsuario(this.listaUsuarios.encontrarUsuarioMail(eMail));
					}
				} catch (IOException e) {
					System.out.println("El archivo no tiene datos 'Usuarios-Pagina.txt'");
				}
			}
		}
		
		
		// Lee todos los administradores de un grupo
		for(int i=0; i<cantPaginasGrupo; i++){
			paginaGrupo pG = this.listaPaginasGrupo.getPaginaGrupoI(i);
			if(pG instanceof Grupo){
				try{
					ArchivoEntrada cargarAdminGrupos = new ArchivoEntrada("Administradores-"+this.listaPaginasGrupo.getPaginaGrupoI(i).getCodigo()+".txt");
					while(!cargarAdminGrupos.isEndFile()){
						Registro r = cargarAdminGrupos.getRegistro();
						String eMail = r.getString();
						((Grupo)pG).getAdministradores().insertarUsuario(this.listaUsuarios.encontrarUsuarioMail(eMail));
					}
				} catch (IOException e) {
					System.out.println("El archivo no tiene datos 'Administradores-Grupo.txt'");
				}
			}
		}
		
		// Lee todos los usuarios de un grupo
		for(int i=0; i<cantPaginasGrupo; i++){
			paginaGrupo pG = this.listaPaginasGrupo.getPaginaGrupoI(i);
			if(pG instanceof Grupo){
				try{
					ArchivoEntrada cargarUsuariosGrupo = new ArchivoEntrada("Usuarios-"+this.listaPaginasGrupo.getPaginaGrupoI(i).getCodigo()+".txt");
					while(!cargarUsuariosGrupo.isEndFile()){
						Registro r = cargarUsuariosGrupo.getRegistro();
						String eMail = r.getString();
						((Grupo)pG).getListaUsuarios().insertarUsuario(this.listaUsuarios.encontrarUsuarioMail(eMail));
					}
				} catch (IOException e) {
					System.out.println("El archivo no tiene datos 'Usuarios-Grupo.txt'");
				}
			}
		}
	}

	@Override
	public void saveDataInformation() {
		// Guarda todos los usuarios nuevos.
		
		int cantUsuarios = this.listaUsuarios.getCantUsuarios();
		try{
			ArchivoSalida guardarUsuarios = new ArchivoSalida("Usuarios.txt");
			for(int i=0; i<cantUsuarios; i++){
				Registro r = new Registro(6);
				r.agregarCampo(this.getListaUsuarios().getUsuarioI(i).getNombres());
				r.agregarCampo(this.getListaUsuarios().getUsuarioI(i).getApellidos());
				r.agregarCampo(this.getListaUsuarios().getUsuarioI(i).geteMail());
				r.agregarCampo(this.getListaUsuarios().getUsuarioI(i).getPassword());
				r.agregarCampo(this.getListaUsuarios().getUsuarioI(i).getFechaNacimiento());
				r.agregarCampo(this.getListaUsuarios().getUsuarioI(i).getSexo());
				guardarUsuarios.writeRegistro(r);
			}
			guardarUsuarios.close();
		} catch (IOException e) {
			System.out.println("No se pudo guardar a los usuarios.");
		}
		
		// Guarda todas las paginas (Negocio) nuevas.
		int cantPaginasGrupo = this.listaPaginasGrupo.getCantPaginasGrupo();
		try{
			ArchivoSalida guardarPaginasNegocio = new ArchivoSalida("PaginasNegocio.txt");
			for(int i=0; i<cantPaginasGrupo; i++){
				paginaGrupo pG = this.listaPaginasGrupo.getPaginaGrupoI(i);
				if(pG instanceof PaginaNegocio){
					Registro r = new Registro(10);
					r.agregarCampo(((PaginaNegocio)pG).getCodigo());
					r.agregarCampo(((PaginaNegocio)pG).getNombre());
					r.agregarCampo(((PaginaNegocio)pG).getFechaCreacion());
					r.agregarCampo(((PaginaNegocio)pG).getCategoria());
					r.agregarCampo(((PaginaNegocio)pG).getClasificacion());
					r.agregarCampo(((PaginaNegocio)pG).getDireccion());
					r.agregarCampo(((PaginaNegocio)pG).getNombreCiudad());
					r.agregarCampo(((PaginaNegocio)pG).getCodigoPostal());
					r.agregarCampo(((PaginaNegocio)pG).getTelefono());
					r.agregarCampo(((PaginaNegocio)pG).getCreador().geteMail());
					guardarPaginasNegocio.writeRegistro(r);
				}
			}
			guardarPaginasNegocio.close();
		} catch (IOException e) {
			System.out.println("No se pudo guardar la PaginaNegocio.");
		}
		
		// Guarda todas las paginas (que no sean negocio) nuevas.
		try{
			ArchivoSalida guardarPaginasOtro= new ArchivoSalida("PaginasOtro.txt");
			for(int i=0; i<cantPaginasGrupo; i++){
				paginaGrupo pG = this.listaPaginasGrupo.getPaginaGrupoI(i);
				if(pG instanceof Pagina){
					Registro r = new Registro(6);
					r.agregarCampo(((Pagina)pG).getCodigo());
					r.agregarCampo(((Pagina)pG).getNombre());
					r.agregarCampo(((Pagina)pG).getFechaCreacion());
					r.agregarCampo(((Pagina)pG).getCategoria());
					r.agregarCampo(((Pagina)pG).getClasificacion());
					r.agregarCampo(((Pagina)pG).getCreador().geteMail());
					if(!((Pagina)pG).getClasificacion().equals("Lugar/Negocio Local")){
						guardarPaginasOtro.writeRegistro(r);
					}
				}
			}
			guardarPaginasOtro.close();
		} catch (IOException e) {
			System.out.println("No se pudo guardar la PaginaOtro.");
		}
		
		
		// Guarda todos los grupos nuevos.
		try{
			ArchivoSalida guardarGrupos = new ArchivoSalida("Grupos.txt");
			for(int i=0; i<cantPaginasGrupo; i++){
				paginaGrupo pG = this.listaPaginasGrupo.getPaginaGrupoI(i);
				if(pG instanceof Grupo){
					Registro r = new Registro(4);
					r.agregarCampo(((Grupo)pG).getCodigo());
					r.agregarCampo(((Grupo)pG).getNombre());
					r.agregarCampo(((Grupo)pG).getFechaCreacion());
					r.agregarCampo(((Grupo)pG).getCreador().geteMail());
					guardarGrupos.writeRegistro(r);
				}
			}
			guardarGrupos.close();
		} catch (IOException e) {
			System.out.println("No se pudo guardar la PaginaNegocio.");
		}
		
		
		// Guarda los amigos de todos los usuarios.
		for(int i=0; i<cantUsuarios; i++){
			try{
				ArchivoSalida guardarAmigos = new ArchivoSalida("Amigos-"+this.listaUsuarios.getUsuarioI(i).geteMail()+".txt");
				int cantAmigosUsuario = this.listaUsuarios.getUsuarioI(i).getListaAmigos().getCantUsuarios();
				if(cantAmigosUsuario!=0){
					for(int x=0; x<cantAmigosUsuario; x++){
						Registro r = new Registro(1);
						r.agregarCampo(this.listaUsuarios.getUsuarioI(i).getListaAmigos().getUsuarioI(x).geteMail());
						guardarAmigos.writeRegistro(r);
					}
					guardarAmigos.close();
				}
			} catch (IOException e) {
				System.out.println("No se pudo guardar el archivo 'Amigos-Usuario.txt'");
			}
		}
		
		// Guarda las paginas y grupos de todos los usuarios.
		for(int i=0; i<cantUsuarios; i++){
			try{
				ArchivoSalida guardarPaginas = new ArchivoSalida("PaginasGrupo-"+this.listaUsuarios.getUsuarioI(i).geteMail()+".txt");
				int cantPaginasUsuario = this.listaUsuarios.getUsuarioI(i).getPaginasGrupo().getCantPaginasGrupo();
				if(cantPaginasUsuario!=0){
					for(int x=0; x<cantPaginasUsuario; x++){
						paginaGrupo pG = this.listaUsuarios.getUsuarioI(i).getPaginasGrupo().getPaginaGrupoI(x);
						Registro r = new Registro(1);	
						r.agregarCampo(pG.getCodigo());
						guardarPaginas.writeRegistro(r);
						
					}
					guardarPaginas.close();
				}
			} catch (IOException e) {
				System.out.println("No se pudo guardar el archivo 'PaginasGrupo-Usuario.txt'");
			}
		}
		
		// Guarda todos los usuarios de una ppagina
		for(int i=0; i<cantPaginasGrupo; i++){
			paginaGrupo pG = this.listaPaginasGrupo.getPaginaGrupoI(i);
			if(pG instanceof Pagina){
				try{
					ArchivoSalida guardarUsuariosPagina = new ArchivoSalida("Usuarios-"+this.listaPaginasGrupo.getPaginaGrupoI(i).getCodigo()+".txt");
					int cantUsuariosPagina = ((Pagina)pG).getListaUsuarios().getCantUsuarios();
					if(cantUsuariosPagina!=0){
						for(int x=0; x<cantUsuariosPagina;x++){
							String eMail = ((Pagina)pG).getListaUsuarios().getUsuarioI(x).geteMail();
							Registro r = new Registro(1);
							r.agregarCampo(eMail);
							guardarUsuariosPagina.writeRegistro(r);
						}
						guardarUsuariosPagina.close();
					}
				} catch (IOException e) {
					System.out.println("No se pudo guardar el archivo 'PaginasGrupo-Usuario.txt'");
				}
			}
		}
		
		// Guarda los administradores de un grupo
		for(int i=0; i<cantPaginasGrupo; i++){
			paginaGrupo pG = this.listaPaginasGrupo.getPaginaGrupoI(i);
			if(pG instanceof Grupo){
				try{
					ArchivoSalida guardarAdministradoresGrupo = new ArchivoSalida("Administradores-"+this.listaPaginasGrupo.getPaginaGrupoI(i).getCodigo()+".txt");
					int cantAdminGrupo = ((Grupo)pG).getAdministradores().getCantUsuarios();
					if(cantAdminGrupo!=0){
						for(int x=0; x<cantAdminGrupo;x++){
							String eMail = ((Grupo)pG).getAdministradores().getUsuarioI(x).geteMail();
							Registro r = new Registro(1);
							r.agregarCampo(eMail);
							guardarAdministradoresGrupo.writeRegistro(r);
						}
						guardarAdministradoresGrupo.close();
					}
				} catch (IOException e) {
					System.out.println("No se pudo guardar el archivo 'PaginasGrupo-Usuario.txt'");
				}
			}
		}
		
		// Guarda los usuarios de un grupo
				for(int i=0; i<cantPaginasGrupo; i++){
					paginaGrupo pG = this.listaPaginasGrupo.getPaginaGrupoI(i);
					if(pG instanceof Grupo){
						try{
							ArchivoSalida guardarUsuariosGrupo = new ArchivoSalida("Usuarios-"+this.listaPaginasGrupo.getPaginaGrupoI(i).getCodigo()+".txt");
							int cantUsuariosGrupo = ((Grupo)pG).getListaUsuarios().getCantUsuarios();
							if(cantUsuariosGrupo!=0){
								for(int x=0; x<cantUsuariosGrupo;x++){
									String eMail = ((Grupo)pG).getListaUsuarios().getUsuarioI(x).geteMail();
									Registro r = new Registro(1);
									r.agregarCampo(eMail);
									guardarUsuariosGrupo.writeRegistro(r);
								}
								guardarUsuariosGrupo.close();
							}
						} catch (IOException e) {
							System.out.println("No se pudo guardar el archivo 'PaginasGrupo-Usuario.txt'");
						}
					}
				}
	}	
}
