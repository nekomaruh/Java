package logica;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
import dominio.*;
import ucn.*;

/*
 * Integrantes: Johan Ordenes / Cecilia Rojas
 * Comentarios JavaDoc de los metodos RF en clase SistemaFacebook.
 */

public class App {
	/**
	 * @param sys Lee los usuarios y los ingresa al sistema.
	 */
	public static void leerUsuarios(SistemaFacebook sys){
		ArchivoEntrada aUsuarios;
		try {
			aUsuarios = new ArchivoEntrada("Usuarios.txt");
			while(!aUsuarios.isEndFile()){
				Registro r = aUsuarios.getRegistro();
				String nom = r.getString();
				String ape = r.getString();
				String ema = r.getString();
				String pas = r.getString();
				String fna = r.getString();
				char sex = r.getChar();
				try {
					Usuario u = new Usuario(nom,ape,ema,pas,fna,sex);
					sys.ingresarUsuario(u);
				} catch (Exception e) {
					e.getMessage();
				}
			}
		} catch (IOException e) {
			System.out.println("No se puede leer el archivo 'Usuarios.txt'");
		}		
	}
	
	/**
	 * @param sys Lee las paginas tipo negocio y los ingresa al sistema.
	 */
	public static void leerPaginasNegocio(SistemaFacebook sys){
		ArchivoEntrada aPaginas;
		try {
			aPaginas = new ArchivoEntrada("PaginasNegocio.txt");
			while(!aPaginas.isEndFile()){
				Registro r = aPaginas.getRegistro();
				int cod = r.getInt();
				String nom = r.getString();
				String fcr = r.getString();
				String cat = r.getString();
				String cla = r.getString();
				String dir = r.getString();
				String nomC = r.getString();
				String codP =r.getString();
				int tel = r.getInt();
				String eMailCreador =r.getString();
				paginaGrupo p = new PaginaNegocio(cod,nom,fcr,cat,cla,dir,nomC,codP,tel);
				try {
					sys.ingresarGrupoOPagina(p);
					p.setCreador(sys.getListaUsuarios().encontrarUsuarioMail(eMailCreador));
				} catch (Exception e) {
					e.getMessage();
				}
			}
		} catch (IOException e) {
			System.out.println("No se puede leer el archivo 'PaginasNegocio.txt'");
		}		
	}
	
	/**
	 * @param sys Lee las paginas que no sean tipo negocio y las ingresa al sistema.
	 */
	public static void leerPaginasOtro(SistemaFacebook sys){
		ArchivoEntrada aPaginas;
		try {
			aPaginas = new ArchivoEntrada("PaginasOtro.txt");
			while(!aPaginas.isEndFile()){
				Registro r = aPaginas.getRegistro();
				int cod = r.getInt();
				String nom = r.getString();
				String fcr = r.getString();
				String cat = r.getString();
				String cla = r.getString();
				String eMailCreador = r.getString();
				paginaGrupo p = new Pagina(cod,nom,fcr,cat,cla);
				try {
					sys.ingresarGrupoOPagina(p);
					p.setCreador(sys.getListaUsuarios().encontrarUsuarioMail(eMailCreador));
				} catch (Exception e) {
					e.getMessage();
				}
			}
		} catch (IOException e) {
			System.out.println("No se puede leer el archivo 'PaginasOtro.txt'");
		}		
	}
	
	/**
	 * @param sys Lee los grupos y los ingresa al sistema.
	 */
	public static void leerGrupos(SistemaFacebook sys){
		try {
			ArchivoEntrada aGrupos = new ArchivoEntrada("Grupos.txt");
			while(!aGrupos.isEndFile()){
				Registro r = aGrupos.getRegistro();
				int cod = r.getInt();
				String nom = r.getString();
				String fcr = r.getString();
				String eMailCreador = r.getString();
				paginaGrupo pG = new Grupo(cod,nom,fcr);
				try {
					sys.ingresarGrupoOPagina(pG);
					pG.setCreador(sys.getListaUsuarios().encontrarUsuarioMail(eMailCreador));
				} catch (Exception e) {
					e.getMessage();
				}
			}
		} catch (IOException e) {
			System.out.println("No se puede leer el archivo 'Grupos.txt'");
		}		
	}
	
	
	/**
	 * @param sys Registra al usuario y lo ingresa al sistema.
	 */
	public static void registrarUsuario(SistemaFacebook sys){
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		
		String original = "������������������������������������������������������������";
	    String ascii =    "AAAAAAACEEEEIIIIDNOOOOOOUUUUYBaaaaaaaceeeeiiiionoooooouuuuyy";
	    
		System.out.print("Ingrese nombres: ");
		String nom = sc.nextLine().toUpperCase();
		
		String outNom = nom;
		
	    for (int i=0; i<original.length(); i++) {
	        outNom = outNom.replace(original.charAt(i), ascii.charAt(i));
	    }
		
		while(!outNom.contains(" ") || outNom.contains(",")){
			System.out.println("Ingrese ambos nombres por favor (con espacio y sin coma)");
			System.out.print("Ingrese nombres: ");
			nom = sc.nextLine().toUpperCase();
			
			outNom = nom;
		    for (int i=0; i<original.length(); i++) {
		        outNom = outNom.replace(original.charAt(i), ascii.charAt(i));
		    }
		}
		
		System.out.print("Ingrese apellidos: ");
		String ape = sc.nextLine().toUpperCase();
		
		String outApe = ape;
		for (int i=0; i<original.length(); i++) {
			outApe = outApe.replace(original.charAt(i), ascii.charAt(i));
		}
		while(!outApe.contains(" ") || outApe.contains(",")){
			System.out.println("Ingrese ambos apellidos por favor (con espacio y sin coma)");
			System.out.print("Ingrese apellidos: ");
			ape = sc.nextLine().toUpperCase();
			outApe = ape;
			for (int i=0; i<original.length(); i++) {
				outApe = outApe.replace(original.charAt(i), ascii.charAt(i));
			}
		}
		System.out.print("Ingrese e-Mail: ");
		String ema = StdIn.readLine();
		
		String outEma = ema;
		for (int i=0; i<original.length(); i++) {
			outEma = outEma.replace(original.charAt(i), ascii.charAt(i));
		}
		while(!outEma.contains("@") || !outEma.contains(".") || outEma.contains(",")){
			System.out.println("Ingrese un e-Mail valido (y sin comas)");
			System.out.print("Ingrese e-Mail: ");
			ema = sc.nextLine();
			outEma = ema;
			for (int i=0; i<original.length(); i++) {
				outEma = outEma.replace(original.charAt(i), ascii.charAt(i));
			}
		}
		System.out.print("Ingrese contrasena: ");
		String pass = sc.nextLine();
		
		String outPass = pass;
		for (int i=0; i<original.length(); i++) {
			outPass = outPass.replace(original.charAt(i), ascii.charAt(i));
		}
		while(outPass.contains(",")){
			System.out.println("Ingrese una contrasena sin coma.");
			pass = sc.nextLine();
			outPass = pass;
			for (int i=0; i<original.length(); i++) {
				outPass = outPass.replace(original.charAt(i), ascii.charAt(i));
			}
		}	
		
		Date fecha = null;
		boolean fechaCorrecta=true;
		String fNac=null;
		System.out.print("Ingrese fecha de nacimiento (dd/mmm/yyyy): ");
		try {
			String fNacString = sc.nextLine();
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			fecha = sdf.parse(fNacString);
			fNac = new SimpleDateFormat("dd/MM/yyyy").format(fecha);
		} catch (ParseException e) {
			System.out.println("Ingrese una fecha correcta y sin comas.");
			fechaCorrecta=false;
		}		
		
		while(!fechaCorrecta || fNac.contains("/") && fNac.contains(",")){
			System.out.print("Ingrese fecha de nacimiento (dd/mm/yyyy): ");
			try {
				String fNacString = sc.nextLine();
				SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
				fecha = sdf.parse(fNacString);
				fNac = new SimpleDateFormat("dd/MM/yyyy").format(fecha);
				fechaCorrecta=true;
			} catch (ParseException e) {
				System.out.println("Ingrese una fecha correcta y sin comas.");
			}	
		}

		System.out.print("Ingrese sexo m/f: ");
		char sex = sc.nextLine().toUpperCase().charAt(0);
		
		while(sex!='M' && sex!='F'){
			System.out.println("Ingrese un sexo correcto!.");
			System.out.print("Ingrese sexo (m/f): ");
			sex = sc.nextLine().toUpperCase().charAt(0);
		}
		try{
			Usuario u = new Usuario(outNom, outApe, outEma, outPass, fNac, sex);
			sys.registrarse(u);
			System.out.println();
		}catch(IllegalArgumentException x){
			x.getMessage();
		}
	}
	
	/**
	 * @param sys
	 * @return Inicia sesion del usuario.
	 */
	public static boolean iniciarSesion(SistemaFacebook sys){
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		System.out.println();
		System.out.print("Correo electronico: ");
		String eMail = sc.nextLine();
		System.out.print("Contrasena: ");
		String password = sc.nextLine();
		boolean online = sys.iniciarSesion(eMail, password);
		return online;		
	}
	
	/**
	 * Imprime un menu principal
	 */
	public static void imprimirMenuInicial(){
		System.out.println(" ---- Facebook ----");
		System.out.println(" [1] Iniciar sesion");
		System.out.println(" [2] Registrarse");
		System.out.println(" [3] Salir");
		System.out.println();
		System.out.print("Ingrese una opcion: ");
	}
	
	/**
	 * Imprime el segundo menu, que aparece al iniciar sesion.
	 */
	public static void imprimirMenuDeNavegacion(){
		System.out.println(" ----- Facebook (online) -----");
		System.out.println(" [1] Agregar amigos");
		System.out.println(" [2] Eliminar amigos");
		System.out.println(" [3] Crear pagina o grupo");
		System.out.println(" [4] Agregar un amigo a un grupo");
		System.out.println(" [5] Buscar y unirse a una pagina");
		System.out.println(" [6] Salirse de una pagina o grupo");
		System.out.println(" [7] Visualizar puntaje");
		System.out.println(" [8] Cerrar sesion");
		System.out.println();
		System.out.print("Ingrese una opcion: ");
	}
	
	public static void main(String[] args){
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		SistemaFacebook sys = new SistemaFacebookImpl();
		leerUsuarios(sys);
		leerPaginasNegocio(sys);
		leerPaginasOtro(sys);
		leerGrupos(sys);
		sys.readDataInformation();
		while(true){
			imprimirMenuInicial();
			String menuOption = sc.nextLine();
			while(!menuOption.equals("1") && !menuOption.equals("2") && !menuOption.equals("3")){
				System.out.println("Ingrese una opcion correcta.");
				System.out.println();
				System.out.print("Ingrese una opcion: ");
				menuOption = sc.nextLine();
			}
			switch(menuOption){
				case "1":
					boolean online = iniciarSesion(sys);
						while(online){
							System.out.println();
							imprimirMenuDeNavegacion();
							String onlineOption =sc.nextLine();
							while(!onlineOption.equals("1") && !onlineOption.equals("2") && !onlineOption.equals("3") && !onlineOption.equals("4") && !onlineOption.equals("5") && !onlineOption.equals("6") && !onlineOption.equals("7") && !onlineOption.equals("8")){
								System.out.println("Ingrese una opcion correcta.");
								System.out.println();
								System.out.print("Ingrese una opcion: ");
								onlineOption = sc.nextLine();
							}
							System.out.println();
							switch(onlineOption){
								case "1":
									System.out.println(" --- Facebook (Agregar amigos) ---");
									System.out.println();
									System.out.print("Ingrese el e-Mail de su amigo: ");
									String eMailAmigo = sc.nextLine();
									try{
										sys.agregarAmigos(eMailAmigo);
									}catch(IllegalArgumentException ex){
										ex.getMessage();
									}
									break;
								case "2":
									try{
										sys.eliminarAmigos();
									}catch(IllegalArgumentException ex){
										ex.getMessage();
									}
									break;
								case "3":
									try{
										sys.crearPaginaOrGrupo();
									}catch(IllegalArgumentException ex){
										ex.getMessage();
									}
									
									break;
								case "4":
									try{
										sys.agregarAmigoToGrupo();
									}catch(IllegalArgumentException ex){
										ex.getMessage();
									}
									break;
								case "5":
									try{
										sys.buscarPaginaAndUnirse();
									}catch(IllegalArgumentException ex){
										ex.getMessage();
									}
									break;
								case "6":
									try{
										sys.salirDeUnaPaginaOrGrupo();
									}catch(IllegalArgumentException ex){
										ex.getMessage();
									}									
									break;
								case "7":
									try{
										sys.verPuntajeUsuario();
									}catch(IllegalArgumentException ex){
										ex.getMessage();
									}									
									break;
								case "8":
									try{
										online = sys.cerrarSesion();
									}catch(IllegalArgumentException ex){
										ex.getMessage();
									}									
									break;
							}
						}
					break;
				case "2":
					try{
						registrarUsuario(sys);
					}catch(IllegalArgumentException ex){
						ex.getMessage();
					}
					break;
				case "3":
					sys.saveDataInformation();
					System.exit(0);
					break;
			}
			
		}
	}
	

}
