package dominio;

public class Trabajador extends Persona{
	protected String cargo;

	public Trabajador(String rut, String nombres, String apellidos, int edad, int telefono, String eMail,
			String cargo) {
		super(rut, nombres, apellidos, edad, telefono, eMail);
		this.cargo = cargo;
	}

	public String getCargo() {
		return cargo;
	}

	public void setCargo(String cargo) {
		this.cargo = cargo;
	}

}
