package dominio;

public class NodoMaterial {
	private NodoMaterial next;
	private NodoMaterial previo;
	private Material material;
	
	public NodoMaterial(Material material) {
		this.next = null;
		this.previo = null;
		this.material = material;
	}

	public NodoMaterial getNext() {
		return next;
	}

	public void setNext(NodoMaterial next) {
		this.next = next;
	}

	public NodoMaterial getPrevio() {
		return previo;
	}

	public void setPrevio(NodoMaterial previo) {
		this.previo = previo;
	}

	public Material getMaterial() {
		return material;
	}

	public void setMaterial(Material material) {
		this.material = material;
	}

}
