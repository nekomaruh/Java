package dominio;

public class Certificacion {
	private int codCertificacion;
	private String tipoServicio;
	public static int puntajeTotal = 100;
	public static int puntajeAprobacionMinimo;
	public static int duracion;
	
	public Certificacion(int codCertificacion, String tipoServicio) {
		this.codCertificacion = codCertificacion;
		this.tipoServicio = tipoServicio;
	}

	public int getCodCertificacion() {
		return codCertificacion;
	}

	public void setCodCertificacion(int codCertificacion) {
		this.codCertificacion = codCertificacion;
	}

	public String getTipoServicio() {
		return tipoServicio;
	}

	public void setTipoServicio(String tipoServicio) {
		this.tipoServicio = tipoServicio;
	}

	public static int getPuntajeTotal() {
		return puntajeTotal;
	}

	public static void setPuntajeTotal(int puntajeTotal) {
		Certificacion.puntajeTotal = puntajeTotal;
	}

	public static int getPuntajeAprobacionMinimo() {
		return puntajeAprobacionMinimo;
	}

	public static void setPuntajeAprobacionMinimo(int puntajeAprobacionMinimo) {
		Certificacion.puntajeAprobacionMinimo = puntajeAprobacionMinimo;
	}

	public static int getDuracion() {
		return duracion;
	}

	public static void setDuracion(int duracion) {
		Certificacion.duracion = duracion;
	}	
	
}
