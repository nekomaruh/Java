package dominio;

public class NodoSolicitudMaterial {
	private NodoSolicitudMaterial next;
	private SolicitudMaterial solicitudMaterial;
	
	public NodoSolicitudMaterial(SolicitudMaterial solicitudMaterial) {
		this.next = null;
		this.solicitudMaterial = solicitudMaterial;
	}

	public NodoSolicitudMaterial getNext() {
		return next;
	}

	public void setNext(NodoSolicitudMaterial next) {
		this.next = next;
	}

	public SolicitudMaterial getSolicitudMaterial() {
		return solicitudMaterial;
	}

	public void setSolicitudMaterial(SolicitudMaterial solicitudMaterial) {
		this.solicitudMaterial = solicitudMaterial;
	}
	
}
