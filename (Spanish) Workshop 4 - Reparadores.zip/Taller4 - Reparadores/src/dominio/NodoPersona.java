package dominio;

public class NodoPersona {
	private NodoPersona next;
	private Persona persona;
	
	public NodoPersona(Persona persona) {
		this.next = null;
		this.persona = persona;
	}

	public NodoPersona getNext() {
		return next;
	}

	public void setNext(NodoPersona next) {
		this.next = next;
	}

	public Persona getPersona() {
		return persona;
	}

	public void setPersona(Persona persona) {
		this.persona = persona;
	}	
	
}
