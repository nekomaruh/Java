package dominio;

public class NodoServicio {
	private NodoServicio next;
	private NodoServicio previo;
	private Servicio servicio;
	
	public NodoServicio(Servicio servicio) {
		this.next = null;
		this.previo = null;
		this.servicio = servicio;
	}

	public NodoServicio getNext() {
		return next;
	}

	public void setNext(NodoServicio next) {
		this.next = next;
	}

	public NodoServicio getPrevio() {
		return previo;
	}

	public void setPrevio(NodoServicio previo) {
		this.previo = previo;
	}

	public Servicio getServicio() {
		return servicio;
	}

	public void setServicio(Servicio servicio) {
		this.servicio = servicio;
	}

}
