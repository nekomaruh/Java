package dominio;
import java.util.ArrayList;
import logica.ListaOrdServicios;
import logica.ListaSolicitudMateriales;

public class TrabajadorServicio extends Trabajador{
	private ArrayList<Certificacion> listaCertificaciones;
	private ListaOrdServicios listaOrdServicios;
	private ArrayList<HistoricoCertificado> listaHistCertificaciones;
	private ListaSolicitudMateriales listaSolMateriales;
	
	public TrabajadorServicio(String rut, String nombres, String apellidos, int edad, int telefono, String eMail,
			String cargo) {
		super(rut, nombres, apellidos, edad, telefono, eMail, cargo);
		this.listaCertificaciones = new ArrayList<Certificacion>();
		this.listaOrdServicios = new ListaOrdServicios();
		this.listaHistCertificaciones = new ArrayList<HistoricoCertificado>();
		this.listaSolMateriales = new ListaSolicitudMateriales();
	}

	public ArrayList<Certificacion> getListaCertificaciones() {
		return listaCertificaciones;
	}

	public void setListaCertificaciones(ArrayList<Certificacion> listaCertificaciones) {
		this.listaCertificaciones = listaCertificaciones;
	}

	public ListaOrdServicios getListaOrdServicios() {
		return listaOrdServicios;
	}

	public void setListaOrdServicios(ListaOrdServicios listaOrdServicios) {
		this.listaOrdServicios = listaOrdServicios;
	}

	public ArrayList<HistoricoCertificado> getListaHistCertificaciones() {
		return listaHistCertificaciones;
	}

	public void setListaHistCertificaciones(ArrayList<HistoricoCertificado> listaHistCertificaciones) {
		this.listaHistCertificaciones = listaHistCertificaciones;
	}

	public ListaSolicitudMateriales getListaSolMateriales() {
		return listaSolMateriales;
	}

	public void setListaSolMateriales(ListaSolicitudMateriales listaSolMateriales) {
		this.listaSolMateriales = listaSolMateriales;
	}
	
}
