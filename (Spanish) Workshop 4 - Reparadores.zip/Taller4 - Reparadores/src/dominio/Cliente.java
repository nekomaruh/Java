package dominio;
import logica.ListaOrdServicios;

public class Cliente extends Persona{
	private Organizacion organizacion;
	private ListaOrdServicios listaOrdServicios;
	
	public Cliente(String rut, String nombres, String apellidos, int edad, int telefono, String eMail) {
		super(rut, nombres, apellidos, edad, telefono, eMail);
		this.organizacion = null;
		this.listaOrdServicios = new ListaOrdServicios();
	}

	public Organizacion getOrganizacion() {
		return organizacion;
	}

	public void setOrganizacion(Organizacion organizacion) {
		this.organizacion = organizacion;
	}

	public ListaOrdServicios getListaOrdServicios() {
		return listaOrdServicios;
	}

	public void setListaOrdServicios(ListaOrdServicios listaOrdServicios) {
		this.listaOrdServicios = listaOrdServicios;
	}

}
