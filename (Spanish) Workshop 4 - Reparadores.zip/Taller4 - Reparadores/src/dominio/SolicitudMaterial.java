package dominio;
import logica.ListaMateriales;

public class SolicitudMaterial {
	private int codSolicitud;
	private String fechaSolicitud;
	private String horaSolicitud;
	private Trabajador jefeAdmin;
	private Trabajador jefeFinanza;
	private ListaMateriales listaMateriales;
	private TrabajadorServicio trabajadorServicio;
	
	public SolicitudMaterial(int codSolicitud, String fechaSolicitud, String horaSolicitud) {
		this.codSolicitud = codSolicitud;
		this.fechaSolicitud = fechaSolicitud;
		this.horaSolicitud = horaSolicitud;
		this.jefeAdmin = null;
		this.jefeFinanza = null;
		this.listaMateriales = new ListaMateriales();
		this.trabajadorServicio = null;
	}

	public int getCodSolicitud() {
		return codSolicitud;
	}

	public void setCodSolicitud(int codSolicitud) {
		this.codSolicitud = codSolicitud;
	}

	public String getFechaSolicitud() {
		return fechaSolicitud;
	}

	public void setFechaSolicitud(String fechaSolicitud) {
		this.fechaSolicitud = fechaSolicitud;
	}

	public String getHoraSolicitud() {
		return horaSolicitud;
	}

	public void setHoraSolicitud(String horaSolicitud) {
		this.horaSolicitud = horaSolicitud;
	}

	public Trabajador getJefeAdmin() {
		return jefeAdmin;
	}

	public void setJefeAdmin(Trabajador jefeAdmin) {
		this.jefeAdmin = jefeAdmin;
	}

	public Trabajador getJefeFinanza() {
		return jefeFinanza;
	}

	public void setJefeFinanza(Trabajador jefeFinanza) {
		this.jefeFinanza = jefeFinanza;
	}

	public ListaMateriales getListaMateriales() {
		return listaMateriales;
	}

	public void setListaMateriales(ListaMateriales listaMateriales) {
		this.listaMateriales = listaMateriales;
	}

	public TrabajadorServicio getTrabajadorServicio() {
		return trabajadorServicio;
	}

	public void setTrabajadorServicio(TrabajadorServicio trabajadorServicio) {
		this.trabajadorServicio = trabajadorServicio;
	}	
	
}
