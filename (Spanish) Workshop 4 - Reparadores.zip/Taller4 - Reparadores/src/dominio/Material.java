package dominio;

public class Material {
	private int codMaterial;
	private String nombre;
	private int stock;
	private String descripcion;
	
	public Material(int codMaterial, String nombre, int stock, String descripcion) {
		this.codMaterial = codMaterial;
		this.nombre = nombre;
		this.stock = stock;
		this.descripcion = descripcion;
	}

	public int getCodMaterial() {
		return codMaterial;
	}

	public void setCodMaterial(int codMaterial) {
		this.codMaterial = codMaterial;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getStock() {
		return stock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	
}
