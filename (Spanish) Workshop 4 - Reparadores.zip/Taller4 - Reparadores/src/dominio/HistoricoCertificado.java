package dominio;

public class HistoricoCertificado {
	private String fecha;
	private int puntaje;
	private Certificacion certificacion;
	private TrabajadorServicio trabajadorServicio;
	
	public HistoricoCertificado(String fecha, int puntaje) {
		this.fecha = fecha;
		this.puntaje = puntaje;
		this.certificacion = null;
		this.trabajadorServicio = null;
	}

	public String getFecha() {
		return fecha;
	}

	public void setFecha(String fecha) {
		this.fecha = fecha;
	}

	public int getPuntaje() {
		return puntaje;
	}

	public void setPuntaje(int puntaje) {
		this.puntaje = puntaje;
	}

	public Certificacion getCertificacion() {
		return certificacion;
	}

	public void setCertificacion(Certificacion certificacion) {
		this.certificacion = certificacion;
	}

	public TrabajadorServicio getTrabajadorServicio() {
		return trabajadorServicio;
	}

	public void setTrabajadorServicio(TrabajadorServicio trabajadorServicio) {
		this.trabajadorServicio = trabajadorServicio;
	}

}
