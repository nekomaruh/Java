package logica;
import dominio.NodoMaterial;
import dominio.Material;

public class ListaMateriales {
	private NodoMaterial first;

	public ListaMateriales() {
		this.first = null;
	}

	public NodoMaterial getFirst() {
		return first;
	}

	public void setFirst(NodoMaterial first) {
		this.first = first;
	}
	
	public boolean isEmpty(){
		return first==null;
	}
	
	public void insertarMaterial(Material m){
		NodoMaterial currentM = new NodoMaterial(m);
		currentM.setNext(first);
		first=currentM;
	}
	
	public Material buscarMaterialCodigo(int cod){
		NodoMaterial currentM = first;
		while(currentM!=null && currentM.getMaterial().getCodMaterial()!=cod){
			currentM = currentM.getNext();
		}
		if(currentM==null){
			return null;
		}
		else{
			return currentM.getMaterial();
		}
	}
	
	
	
}
