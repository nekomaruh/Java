package logica;

import java.util.ArrayList;
import dominio.*;

public class Reparadores implements IReparadores{
	private ListaPersonas listaPersonas;
	private ListaOrdServicios listaOrdServicios;
	private ListaMateriales listaMateriales;
	private ListaSolicitudMateriales listaSolicitudMateriales;
	private ArrayList <Certificacion> listaCertificaciones;
	private ArrayList <HistoricoCertificado> listaHistoricoCertificado;
	
	public Reparadores() {
		this.listaPersonas = new ListaPersonas();
		this.listaOrdServicios = new ListaOrdServicios();
		this.listaMateriales = new ListaMateriales();
		this.listaSolicitudMateriales = new ListaSolicitudMateriales();
		this.listaCertificaciones = new ArrayList<Certificacion>();
		this.listaHistoricoCertificado = new ArrayList<HistoricoCertificado>();
	}

	public ListaPersonas getListaPersonas() {
		return this.listaPersonas;
	}

	public ListaOrdServicios getListaOrdServicios() {
		return this.listaOrdServicios;
	}

	public ListaMateriales getListaMateriales() {
		return this.listaMateriales;
	}

	public ListaSolicitudMateriales getListaSolicitudMateriales() {
		return this.listaSolicitudMateriales;
	}

	public ArrayList<Certificacion> getListaCertificaciones() {
		return this.listaCertificaciones;
	}

	public ArrayList<HistoricoCertificado> getListaHistoricoCertificado() {
		return this.listaHistoricoCertificado;
	}

	@Override
	public void agregarPersona(Persona p) {
		this.listaPersonas.insertarPersona(p);
	}

	@Override
	public boolean agregarServicios(Servicio s) {
		boolean insertado = this.listaOrdServicios.insertarServicio(s);
		if(!insertado){
			throw new IllegalArgumentException("No se pudo insertar servicio.");
		}
		return insertado;
	}
	
	@Override
	public void agregarMaterial(Material m) {
		this.getListaMateriales().insertarMaterial(m);
	}

	@Override
	public void agregarCertificacion(Certificacion c) {
		this.listaCertificaciones.add(c);
	}

	@Override
	public void agregarHistoricoCertificado(HistoricoCertificado hc) {
		this.listaHistoricoCertificado.add(hc);
	}

	@Override
	public void agregarSolicitudMaterial(SolicitudMaterial sm) {
		this.listaSolicitudMateriales.insertarSolicitudMaterial(sm);
	}

	@Override
	public ListaMateriales obtenerMaterialesTodosLosServicios() {
		ListaMateriales listaNueva = new ListaMateriales();
		NodoMaterial nodoMaterial = this.listaMateriales.getFirst();
		while(nodoMaterial!=null){
			Material m = nodoMaterial.getMaterial();
			NodoServicio ns = this.listaOrdServicios.getFirst();
			boolean esta = true;
			while(ns!=null){
				Material material = ns.getServicio().getListaMateriales().buscarMaterialCodigo(m.getCodMaterial());
				if(material==null){
					esta=false;
				}
				ns = ns.getNext();
			}
			if(esta){
				listaNueva.insertarMaterial(m);
			}
			nodoMaterial = nodoMaterial.getNext();
		}
		return listaNueva;
	}

	@Override
	public ListaMateriales obtenerMaterialesNingunServicio() {

		NodoServicio ns = this.listaOrdServicios.getFirst();
		ListaMateriales nuevaLista = new ListaMateriales();
		while(ns!=null){
			Servicio s = ns.getServicio();
			ListaMateriales lm = s.getListaMateriales();
			if(lm!=null){
				NodoMaterial nm = lm.getFirst();
				while(nm!=null){
					Material m = nm.getMaterial();
					boolean esta=false;
					NodoMaterial nuevoNodo = nuevaLista.getFirst();
					if(nuevaLista.isEmpty()){
						nuevaLista.insertarMaterial(m);
					}else{
						while(nuevoNodo!=null){
							if(m.equals(nuevoNodo.getMaterial())){
								esta=true;
							}
							nuevoNodo = nuevoNodo.getNext();
						}
						if(!esta){
							nuevaLista.insertarMaterial(m);
						}
					}
					nm = nm.getNext();
				}
			}
			ns = ns.getNext();
		}
		
		ListaMateriales returnLista = new ListaMateriales();
		NodoMaterial nodoMaterial= this.listaMateriales.getFirst();
		
		while(nodoMaterial!=null){
			Material material = nodoMaterial.getMaterial();
			boolean esta=false;
			Material nuevoMaterial = nuevaLista.buscarMaterialCodigo(material.getCodMaterial());
			if(nuevoMaterial!=null){
				esta=true;
			}
			if(!esta){
				returnLista.insertarMaterial(material);
			}
			nodoMaterial=nodoMaterial.getNext();
		}

		return returnLista;
		
	}

	@Override
	public ListaOrdServicios obtenerDatosServicioUnTrabajador() {
		NodoServicio nodoServicio = this.listaOrdServicios.getFirst();
		ListaOrdServicios nuevaLista = new ListaOrdServicios();
		while(nodoServicio!=null){
			Servicio servicio = nodoServicio.getServicio();
			if(servicio.getTrabajador2()==null && servicio.getCliente().getOrganizacion()!=null){
				nuevaLista.insertarServicio(servicio);	
			}
			nodoServicio = nodoServicio.getNext();
		}
		return nuevaLista;
	}

	@Override
	public ListaSolicitudMateriales obtenerSolicitudMaterialesRango3a10() {
		ListaSolicitudMateriales nuevaListaSolicitudMaterial = new ListaSolicitudMateriales();
		ListaMateriales nuevaListaMateriales = new ListaMateriales();
		NodoSolicitudMaterial nodoSolicitudMaterial = this.listaSolicitudMateriales.getFirst();
		
		// Inserta la lista nueva lista de materiales para saber la cantidad de materiales
		while(nodoSolicitudMaterial !=null){
			SolicitudMaterial solicitudMaterial = nodoSolicitudMaterial .getSolicitudMaterial();
			NodoMaterial nodoMaterial = solicitudMaterial.getListaMateriales().getFirst();
			int cantMaterialesPedidos=0;
			while(nodoMaterial!=null){
				Material material = nodoMaterial.getMaterial();
				Material buscado = nuevaListaMateriales.buscarMaterialCodigo(material.getCodMaterial());
				if(buscado==null){
					nuevaListaMateriales.insertarMaterial(material);
					cantMaterialesPedidos++;
				}
				nodoMaterial = nodoMaterial.getNext();
			}
			if(cantMaterialesPedidos>=3 && cantMaterialesPedidos<=7){
				nuevaListaSolicitudMaterial.insertarSolicitudMaterial(solicitudMaterial);
				nuevaListaMateriales.setFirst(null);
			}
			
			nodoSolicitudMaterial =nodoSolicitudMaterial .getNext();
		}
		
		return nuevaListaSolicitudMaterial;
	}

	@Override
	public ListaPersonas obtenerTrabajadorConMasServicios() {
		ListaPersonas listaTrabajadoresConMasServicios = new ListaPersonas();
		NodoPersona currentPersona = this.listaPersonas.getFirst();
		int maxServicios=-9999;
		
		// Se busca en la lista el trabajador que posee mas servicios
		while(currentPersona!=null){
			Persona persona = currentPersona.getPersona();
			if(persona instanceof TrabajadorServicio){
				NodoServicio currentServicio = ((TrabajadorServicio)persona).getListaOrdServicios().getFirst();
				int cantServicios=0;
				while(currentServicio!=null){
					cantServicios++;
					currentServicio=currentServicio.getNext();
				}
				if(cantServicios>maxServicios){
					maxServicios=cantServicios;
				}
			}
			currentPersona = currentPersona.getNext();
		}
		currentPersona = this.listaPersonas.getFirst();
		while(currentPersona!=null){
			Persona persona = currentPersona.getPersona();
			if(persona instanceof TrabajadorServicio){
				NodoServicio currentServicio = ((TrabajadorServicio)persona).getListaOrdServicios().getFirst();
				int cantServicios=0;
				while(currentServicio!=null){
					cantServicios++;
					currentServicio=currentServicio.getNext();
				}
				if(cantServicios==maxServicios){
					listaTrabajadoresConMasServicios.insertarPersona(persona);
				}
			}
			currentPersona = currentPersona.getNext();
		}
		
		return listaTrabajadoresConMasServicios;
	}

	

}
