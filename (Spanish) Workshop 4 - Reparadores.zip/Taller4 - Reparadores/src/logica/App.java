package logica;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import dominio.*;
import ucn.*;

/**
 * @author Johan Ordenes / Cecilia Rojas
 * Documentaci�n Java-Doc en la clase Reparadores.
 */

public class App {
	
	public static void leerCertificaciones(IReparadores sistema){
		ArchivoEntrada archCertificaciones;
		try {
			archCertificaciones = new ArchivoEntrada("certificaciones.txt");
			while(!archCertificaciones.isEndFile()){
				Registro r = archCertificaciones.getRegistro();
				int codCertificacion = r.getInt();
				String tipoServicio = r.getString();
				Certificacion c = new Certificacion(codCertificacion,tipoServicio);
				sistema.agregarCertificacion(c);
			}
		} catch (IOException e) {
			System.out.println("No se puede leer el archivo certificaciones.txt");
		}
	}
	
	public static void leerMateriales(IReparadores sistema){
		ArchivoEntrada archMateriales;
		try {
			archMateriales = new ArchivoEntrada("materiales.txt");
			while(!archMateriales.isEndFile()){
				Registro r = archMateriales.getRegistro();
				int codMat = r.getInt();
				String nomMat = r.getString();
				int stockMat = r.getInt();
				String descripcionMat = r.getString();
				Material m = new Material(codMat,nomMat,stockMat,descripcionMat);
				sistema.agregarMaterial(m);
			}
		} catch (IOException e) {
			System.out.println("No se puede leer el archivo materiales.txt");
		}
	}
	
	public static void leerPersonas(IReparadores sistema){
		ArchivoEntrada archPersonas;
		try {
			archPersonas = new ArchivoEntrada("Personas.txt");
			while(!archPersonas.isEndFile()){
				Registro r = archPersonas.getRegistro();
				String rut = r.getString();
				String nombres = r.getString();
				String apellidos = r.getString();
				int edad = r.getInt();
				int telefono = r.getInt();
				String eMail = r.getString();
				String tipo = r.getString();
				if(tipo.equals("C")){
					int tieneOrg = r.getInt();
					Persona pC = new Cliente(rut,nombres,apellidos,edad,telefono,eMail);
					if(tieneOrg==1){
						String rutOrg = r.getString();
						String dirOrg = r.getString();
						String nomOrg = r.getString();
						Organizacion o = new Organizacion(rutOrg,dirOrg,nomOrg);
						((Cliente)pC).setOrganizacion(o);
					}
					sistema.agregarPersona(pC);
				}else{
					if(tipo.equals("T")){
						String cargo = r.getString();
						Persona pT = new Trabajador(rut,nombres,apellidos,edad,telefono,eMail,cargo);
						sistema.agregarPersona(pT);
					}else{
						if(tipo.equals("TS")){
							String cargo = r.getString();
							Persona pTS = new TrabajadorServicio(rut,nombres,apellidos,edad,telefono,eMail,cargo);
							sistema.agregarPersona(pTS);
						}
					}
				}
			}
		} catch (IOException e) {
			System.out.println("No se puede leer el archivo personas.txt");
		}
	}
	
	public static void leerServicios(IReparadores sistema){
		ArchivoEntrada archServicios;
		try {
			archServicios = new ArchivoEntrada("servicios.txt");
			while(!archServicios.isEndFile()){
				Registro r = archServicios.getRegistro();
				int codServicio = r.getInt();
				String fechaServicio = r.getString();
				String horaServicio = r.getString();
				String rutCliente = r.getString();
				String rutTrabajador1 = r.getString();
				String rutTrabajador2 = r.getString();
				int codCertificacion = r.getInt();
				
				Servicio s = new Servicio(codServicio,fechaServicio,horaServicio);	
				Cliente cl = (Cliente)sistema.getListaPersonas().buscarPersonaRut(rutCliente);
				TrabajadorServicio t1 = (TrabajadorServicio)sistema.getListaPersonas().buscarPersonaRut(rutTrabajador1);
				TrabajadorServicio t2 = (TrabajadorServicio)sistema.getListaPersonas().buscarPersonaRut(rutTrabajador2);
				s.setCliente(cl);
				s.setTrabajador1(t1);
				if(!rutTrabajador2.equals("0")){
					s.setTrabajador2(t2);
				}
				Iterator<Certificacion>it=sistema.getListaCertificaciones().iterator();
				while(it.hasNext()){
					Certificacion certif = (Certificacion)it.next();
					if(certif.getCodCertificacion()==codCertificacion){
						s.setCertificacion(certif);
					}
				}		
				
				sistema.agregarServicios(s); // Inserta el servicio a la lista general de servicios
							
				cl.getListaOrdServicios().insertarServicio(s); // Inserta el sevicio a al cliente
				t1.getListaOrdServicios().insertarServicio(s); // Inserta el servicio al trabajador 1
				if(t2!=null){ // Inserta el servicio al trabajador 2 si existe
			    	t2.getListaOrdServicios().insertarServicio(s);
				}
				
			}
		} catch (IOException e) {
			System.out.println("No se puede leer el archivo servicios.txt");
		}
	}
	
	public static void leerHistoricoCertificaciones(IReparadores sistema){
		ArchivoEntrada archHistCertificaciones;
		try {
			archHistCertificaciones = new ArchivoEntrada("historico_certificado.txt");
			while(!archHistCertificaciones.isEndFile()){
				Registro r = archHistCertificaciones.getRegistro();
				String fecha = r.getString();
				int puntaje = r.getInt();
				int codCertificacion = r.getInt();
				String rutTrabajadorServicio = r.getString();
				HistoricoCertificado histCertificacion = new HistoricoCertificado(fecha,puntaje);
				Iterator<Certificacion> it = sistema.getListaCertificaciones().iterator();
				while(it.hasNext()){
					Certificacion certificacion = (Certificacion)it.next();
					if(certificacion.getCodCertificacion()==codCertificacion){
						histCertificacion.setCertificacion(certificacion);
						break;
					}
				}
				TrabajadorServicio ts = (TrabajadorServicio)sistema.getListaPersonas().buscarPersonaRut(rutTrabajadorServicio);
				histCertificacion.setTrabajadorServicio(ts);
				
				sistema.getListaHistoricoCertificado().add(histCertificacion);
				ts.getListaHistCertificaciones().add(histCertificacion);
			}
		} catch (IOException e) {
			System.out.println("No se puede leeer historico_certificado.txt");
		}
	}
	
	public static void leerServicioMaterial(IReparadores sistema){
		try {
			ArchivoEntrada archServicioMaterial = new ArchivoEntrada("servicio_material.txt");
			while(!archServicioMaterial.isEndFile()){
				Registro r = archServicioMaterial.getRegistro();
				int codServicio = r.getInt();
				int codMaterial = r.getInt();
				int cantUtilizado = r.getInt();
				Servicio s = sistema.getListaOrdServicios().buscarServicioCod(codServicio);
				Material m = sistema.getListaMateriales().buscarMaterialCodigo(codMaterial);
				int cantidad=0;
				while(cantidad<cantUtilizado){
					s.getListaMateriales().insertarMaterial(m);
					cantidad++;
				}
			}
		} catch (IOException e) {
			System.out.println("No se puede leer el archivo servicio_material.txt");
		}
		
	}
	
	public static void leerSolicitudMateriales(IReparadores sistema){
		ArchivoEntrada archSolicitudMateriales;
		try {
			archSolicitudMateriales = new ArchivoEntrada("solicitud_material.txt");
			while(!archSolicitudMateriales.isEndFile()){
				Registro r = archSolicitudMateriales.getRegistro();
				int cod = r.getInt();
				String fecha = r.getString();
				String hora = r.getString();
				String rutTS = r.getString();
				String rutTJF = r.getString();
				String rutTJA = r.getString();
				SolicitudMaterial sm = new SolicitudMaterial(cod,fecha,hora);
				TrabajadorServicio tS = (TrabajadorServicio)sistema.getListaPersonas().buscarPersonaRut(rutTS);
				Trabajador tF = (Trabajador)sistema.getListaPersonas().buscarPersonaRut(rutTJF);
				Trabajador tA = (Trabajador)sistema.getListaPersonas().buscarPersonaRut(rutTJA);
				sm.setTrabajadorServicio(tS);
				sm.setJefeFinanza(tF);
				sm.setJefeAdmin(tA);
				tS.getListaSolMateriales().insertarSolicitudMaterial(sm);
				sistema.agregarSolicitudMaterial(sm);
				
			}
		} catch (IOException e) {
			System.out.println("No se puede leer el archivo solicitud_material.txt");
		}
	}
	
	public static void leerSolicitudMaterialMaterial(IReparadores sistema){
		try{
			ArchivoEntrada archMaterialSolicitado = new ArchivoEntrada("solicitud_material_material.txt");
			while(!archMaterialSolicitado.isEndFile()){
				Registro r = archMaterialSolicitado.getRegistro();
				int codSolicitud = r.getInt();
				int codMaterial = r.getInt();
				int cantMaterial = r.getInt();
				Material m = sistema.getListaMateriales().buscarMaterialCodigo(codMaterial);
				SolicitudMaterial sm = sistema.getListaSolicitudMateriales().buscarSolicitudCodigo(codSolicitud);
				int cant=0;
				while(cant<cantMaterial){
					sm.getListaMateriales().insertarMaterial(m);
					cant++;
				}
				
			}
		} catch (IOException e) {
			System.out.println("No se puede leer el archivo solicitud_material_material.txt");
		}
	}
	
	
	
	/**
	 * Lee todos los archivos a traves de un s�lo metodo, hace uso de los 
	 * subprogramas que leen archivos.
	 */
	public static void RF1(IReparadores sistema){
		leerCertificaciones(sistema);
		leerMateriales(sistema);
		leerPersonas(sistema);
		leerServicios(sistema);
		leerHistoricoCertificaciones(sistema);
		leerServicioMaterial(sistema);
		leerSolicitudMateriales(sistema);
		leerSolicitudMaterialMaterial(sistema);
	}
	
	/**
	 * Despliega por pantalla los datos de los materiales usados en todos los servicios.
	 */
	public static void mostrarMaterialesConServiciosRF2(IReparadores sistema){
		System.out.println(" --- MATERIALES QUE HAN SIDO UTILIZADOS EN TODOS LOS SERVICIOS ---");
		System.out.println();
		ListaMateriales lm = sistema.obtenerMaterialesTodosLosServicios();
		NodoMaterial nm = lm.getFirst();
		while(nm!=null){
			Material m = nm.getMaterial();
			System.out.println(" � Codigo: "+m.getCodMaterial());
			System.out.println(" � Nombre: "+m.getNombre());
			System.out.println(" � Descripcion: "+m.getDescripcion());
			System.out.println(" � Stock: "+m.getStock());
			System.out.println();
			System.out.println(" ------------------------------------------------------------------");
			System.out.println();
			nm = nm.getNext();
		}
	}	
	
	
	/**
	 * Despliega por pantalla los datos de los materiales no usados en ningun servicios.
	 */
	public static void mostrarMaterialesSinServiciosRF2(IReparadores sistema){
		System.out.println(" --- MATERIALES QUE NO HAN SIDO UTILIAZADOS EN UN SERVICIO ---");
		System.out.println();
		ListaMateriales lm = sistema.obtenerMaterialesNingunServicio();
		NodoMaterial nm = lm.getFirst();
		while(nm!=null){
			Material m = nm.getMaterial();
			System.out.println(" � Codigo: "+m.getCodMaterial());
			System.out.println(" � Nombre: "+m.getNombre());
			System.out.println(" � Descripcion: "+m.getDescripcion());
			System.out.println(" � Stock: "+m.getStock());
			System.out.println();
			nm = nm.getNext();
		}
	}
	
	/**
	 * Met�do que hace uso de dos subprogramas para responder al
	 * segundo requisito funcional.
	 */
	public static void RF2(IReparadores sistema){
		mostrarMaterialesConServiciosRF2(sistema);
		mostrarMaterialesSinServiciosRF2(sistema);
	}
	
	/**
	 * Despliega por pantalla los datos de los servicios en donde participo
	 * s�lo un trabajador. Estos clientes son organizaciones.
	 */
	public static void RF3(IReparadores sistema){
		System.out.println(" --- SERVICIOS DONDE PARTICIPO SOLO UN TRABAJADOR EN UNA ORGANIZACION ---");
		System.out.println();
		ListaOrdServicios ls = sistema.obtenerDatosServicioUnTrabajador();
		NodoServicio ns = ls.getFirst();
		while(ns!=null){
			Servicio s = ns.getServicio();
			System.out.println(" � Codigo: "+s.getCodServicio());
			System.out.println(" � Fecha y hora: "+s.getFechaServicio()+" "+s.getHoraServicio());
			System.out.println(" � Nombre cliente: "+s.getCliente().getNombres()+" "+s.getCliente().getApellidos());
			System.out.println(" � Nombre organizacion: "+s.getCliente().getOrganizacion().getNombreOrg());
			System.out.println(" � Nombre trabajador de servicio: "+s.getTrabajador1().getNombres()+" "+s.getTrabajador1().getApellidos());
			System.out.println();
			NodoMaterial nodoMaterial = s.getListaMateriales().getFirst();
			// Crea una lista de los materiales a imprimir
			ListaMateriales listaMaterialesServicio = new ListaMateriales(); 
			while(nodoMaterial!=null){
				Material material = nodoMaterial.getMaterial();
				Material buscado = listaMaterialesServicio.buscarMaterialCodigo(material.getCodMaterial());
				if(buscado==null){
					listaMaterialesServicio.insertarMaterial(material);
				}
				nodoMaterial = nodoMaterial.getNext();
			}
			NodoMaterial nodoNuevaLista = listaMaterialesServicio.getFirst();
			while(nodoNuevaLista!=null){
				Material nuevoMaterial = nodoNuevaLista.getMaterial();
				System.out.println("   � Material: "+nuevoMaterial.getNombre());
				NodoMaterial nodoAux = s.getListaMateriales().getFirst();
				int cantMaterial=0;
				while(nodoAux!=null){
					if(nodoAux.getMaterial().equals(nuevoMaterial)){
						cantMaterial++;
					}
					nodoAux=nodoAux.getNext();
				}
				System.out.println("   � Cantidad: "+cantMaterial);
				System.out.println();
				nodoNuevaLista = nodoNuevaLista.getNext();
			}
			System.out.println(" ------------------------------------------------------------------");
			System.out.println();
			ns = ns.getNext();
		}
	}
	
	/**
	 * Despliega por pantalla los datos de las solicitudes en donde
	 * se piden de 3 a 10 materiales.
	 */
	public static void RF4(IReparadores sistema){
		System.out.println(" --- SOLICITUDES DE MATERIALES QUE PIDEN ENTRE DE 3 A 10 MATERIALES ---");
		System.out.println();
		ListaSolicitudMateriales ls = sistema.obtenerSolicitudMaterialesRango3a10();
		NodoSolicitudMaterial nsm = ls.getFirst();
		while(nsm!=null){
			SolicitudMaterial s = nsm.getSolicitudMaterial();
			System.out.println(" � Codigo: "+s.getCodSolicitud());
			System.out.println(" � Fecha y hora: "+s.getFechaSolicitud()+" "+s.getHoraSolicitud());
			System.out.println(" � Nombre del jefe de administracion que aprobo la solicitud: "+s.getJefeAdmin().getNombres()+" "+s.getJefeAdmin().getApellidos());
			System.out.println(" � Nombre del jefe de finanzas que aprobo la solicitud: "+s.getJefeFinanza().getNombres()+" "+s.getJefeFinanza().getApellidos());
			System.out.println(" � Nombre del trabajador que lo solicito: "+s.getTrabajadorServicio().getNombres()+" "+s.getTrabajadorServicio().getApellidos());
			System.out.println();
			System.out.println(" ------------------------------------------------------------------");
			System.out.println();
			nsm = nsm.getNext();
		}
	}
	
	/**
	 * Despliega por pantalla el o los trabajadores de servicios que han realizado
	 * mas servicios. 
	 */
	public static void RF5(IReparadores sistema){
		System.out.println(" --- TRABAJADORES QUE HAN REALIZADO MAS SERVICIOS ---");
		System.out.println();
		ListaPersonas listaTabajadoresConMasServicios = sistema.obtenerTrabajadorConMasServicios();
		NodoPersona np = listaTabajadoresConMasServicios.getFirst();
		while(np!=null){
			Persona persona = np.getPersona();
			System.out.println(" � Nombres y Apellidos: "+((TrabajadorServicio)persona).getNombres()+" "+((TrabajadorServicio)persona).getApellidos());
			ArrayList<HistoricoCertificado> listaHistorico = ((TrabajadorServicio)persona).getListaHistCertificaciones();
			Iterator<HistoricoCertificado> it = listaHistorico.iterator();
			System.out.println();
			while(it.hasNext()){
				HistoricoCertificado historico = (HistoricoCertificado)it.next();
				System.out.println(" � Fecha de rendicion del examen: "+historico.getFecha());
				System.out.println(" � Puntaje obtenido: "+historico.getPuntaje()+"/"+Certificacion.getPuntajeTotal());
				System.out.println(" � Codigo del certificado: "+historico.getCertificacion().getCodCertificacion());
				System.out.println(" � Tipo de servicio del certificado: "+historico.getCertificacion().getTipoServicio());
				if(historico.getPuntaje()<80){
					System.out.println(" � Aprobado: NO");
				}else{
					System.out.println(" � Aprobado: SI");
				}
				System.out.println();
			}
			
			np = np.getNext();
		}
	}
	
	public static void main(String[] args) {
		IReparadores sistema = new Reparadores();
		System.out.println();
		System.out.println("                  ---       REPARADORES       ---");
		System.out.println();
		try{
			RF1(sistema);
		}catch(IllegalArgumentException ex){
			ex.getMessage();
		}
		try{
			RF2(sistema);
		}catch(IllegalArgumentException ex){
			ex.getMessage();
		}
		
		try{
			RF3(sistema);
		}catch(IllegalArgumentException ex){
			ex.getMessage();
		}
		
		try{
			RF4(sistema);
		}catch(IllegalArgumentException ex){
			ex.getMessage();
		}
		
		try{
			RF5(sistema);
		}catch(IllegalArgumentException ex){
			ex.getMessage();
		}

	}
}
