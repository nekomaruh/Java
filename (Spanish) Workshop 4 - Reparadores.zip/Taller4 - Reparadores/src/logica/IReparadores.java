package logica;

import java.util.ArrayList;
import dominio.*;

public interface IReparadores {
	
	/**
	 * Ingresa una persona a la lista global de personas.
	 */
	public void agregarPersona(Persona p);
	
	
	/**
	 * @return Agrega un servicio a la lista global de servicios.
	 */
	public boolean agregarServicios(Servicio s);
	
	
	/**
	 * Ingresa un material a la lista global de materiales.
	 */
	public void agregarMaterial(Material m);
	
	
	/**
	 * Ingresa una certificacion a la lista global de certificaciones.
	 */
	public void agregarCertificacion(Certificacion c);
	
	
	/**
	 * Ingresa el historico certificado a la lista global de historico certificado.
	 */
	public void agregarHistoricoCertificado(HistoricoCertificado hc);
	
	
	/**
	 * Ingresa las solicitudes de materiales a la lista global de solicitudes de materiales.
	 */
	public void agregarSolicitudMaterial(SolicitudMaterial sm);
	
	
	/**
	 * @return Retorna la lista de materiales que estan presentes en todos los servicios. 
	 */
	public ListaMateriales obtenerMaterialesTodosLosServicios();
	
	
	/**
	 * @return Retorna la lista de materiales que no estan presentes en nigun servicio.
	 */
	public ListaMateriales obtenerMaterialesNingunServicio();
	
	
	/**
	 * @return Retorna la lista de servicios para la cual, s�lo participo un trabajador,
	 * y el servicio al que se le hizo mantenimiento fue una empresa.
	 */
	public ListaOrdServicios obtenerDatosServicioUnTrabajador();
	
	
	/**
	 * @return Retona la lista de solicitudes de material, cuyas solicitudes s�lo
	 * piden materiales en un rango entre 3 a 10 (incluyendo el 3 y el 10).
	 */
	public ListaSolicitudMateriales obtenerSolicitudMaterialesRango3a10();
	
	
	/**
	 * @return Retorna la lista de trabajadores que han realizado mas servicios.
	 * Se refiere al trabajador que ha realizado mas servicios, pero puede que
	 * otro trabajador tambi�n haya realizado la misma cantidad maxima de servicios.
	 * Por eso se retorna la lista.
	 */
	public ListaPersonas obtenerTrabajadorConMasServicios();
	
	/**
	 * @return Obtiene la lista global de personas.
	 */
	public ListaPersonas getListaPersonas();
	
	
	/**
	 * @return Obtiene la lista global de servicios.
	 */
	public ListaOrdServicios getListaOrdServicios();
	
	
	/**
	 * @return Obtiene la lista global de materiales.
	 */
	public ListaMateriales getListaMateriales();
	
	
	/**
	 * @return Obtiene la losta global de solicitudes de material.
	 */
	public ListaSolicitudMateriales getListaSolicitudMateriales();
	
	
	/**
	 * @return Obtiene la lista gobal de certificaciones.
	 */
	public ArrayList<Certificacion> getListaCertificaciones();
	
	
	/**
	 * @return Obtiene la lista global de historicos certificado.
	 */
	public ArrayList<HistoricoCertificado> getListaHistoricoCertificado();
	
}
