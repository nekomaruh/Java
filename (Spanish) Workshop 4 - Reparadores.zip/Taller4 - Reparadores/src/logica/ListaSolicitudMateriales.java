package logica;

import dominio.NodoSolicitudMaterial;
import dominio.SolicitudMaterial;

public class ListaSolicitudMateriales {
	private NodoSolicitudMaterial first;

	public ListaSolicitudMateriales() {
		this.first = null;
	}

	public NodoSolicitudMaterial getFirst() {
		return first;
	}

	public void setFirst(NodoSolicitudMaterial first) {
		this.first = first;
	}
	
	public void insertarSolicitudMaterial(SolicitudMaterial s){
		NodoSolicitudMaterial current = new NodoSolicitudMaterial(s);
		current.setNext(first);
		first=current;
	}
	
	public SolicitudMaterial buscarSolicitudCodigo(int cod){
		NodoSolicitudMaterial current = first;
		while(current!=null && current.getSolicitudMaterial().getCodSolicitud()!=cod){
			current = current.getNext();
		}
		if(current!=null){
			return current.getSolicitudMaterial();
		}
		else{
			return null;
		}
	}
		
}
