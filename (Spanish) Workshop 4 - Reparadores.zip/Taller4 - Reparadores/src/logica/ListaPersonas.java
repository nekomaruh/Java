package logica;
import dominio.NodoPersona;
import dominio.Persona;

public class ListaPersonas {
	private NodoPersona first;

	public ListaPersonas() {
		this.first = null;
	}
	
	public void insertarPersona(Persona p){
		NodoPersona currentP = new NodoPersona(p);
		currentP.setNext(first);
		first=currentP;
	}
	
	public Persona buscarPersonaRut(String rut){
		NodoPersona currentP = first;
		while(currentP!=null && !currentP.getPersona().getRut().equals(rut)){
			currentP = currentP.getNext();
		}
		if(currentP!=null){
			return currentP.getPersona();
		}
		else{
			return null;
		}
	}

	public NodoPersona getFirst() {
		return first;
	}

	public void setFirst(NodoPersona first) {
		this.first = first;
	}

}
