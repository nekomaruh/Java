package logica;

import dominio.NodoServicio;
import dominio.Servicio;

public class ListaOrdServicios {
	private NodoServicio first;
	private NodoServicio last;
	
	public ListaOrdServicios() {
		this.first = null;
		this.last = null;
	}

	public NodoServicio getFirst() {
		return first;
	}

	public void setFirst(NodoServicio first) {
		this.first = first;
	}

	public NodoServicio getLast() {
		return last;
	}

	public void setLast(NodoServicio last) {
		this.last = last;
	}
	
	public Servicio buscarServicioCod(int cod){
		NodoServicio currentS = first;
		while(currentS!=null && currentS.getServicio().getCodServicio()!=cod){
			currentS = currentS.getNext();
		}
		if(currentS!=null){
			return currentS.getServicio();
		}
		else{
			return null;
		}
	}
	
	public boolean isEmpty(){
		return first==null;
	}
	
	public boolean insertarServicio(Servicio s){
		NodoServicio nodoNuevo = new NodoServicio(s);
		if(isEmpty()){
			first=nodoNuevo;
			last=nodoNuevo;
			return true;
		}else{
			last.setNext(nodoNuevo);      
			nodoNuevo.setPrevio(last);
			
			NodoServicio current = first;
			int max=0;
			while(current!=null){
				current=current.getNext();
				max++;
			}
			
			current = first;
			int pos=0;
			NodoServicio[]array = new NodoServicio[max];
			while(current!=null && pos<max){
				array[pos]=current;
				pos++;
				current = current.getNext();
			}
			
			NodoServicio aux;
		
			//Ordenamiento burbuja por segundo
			for(int x=0; x<=max-2; x++){
				for(int y=max-1; y>=x+1; y--){
					
					NodoServicio actual = array[y];
					String[] s1 = actual.getServicio().getHoraServicio().split(":");
					int seg = Integer.parseInt(s1[2]);
					
					NodoServicio anterior = array[y-1];
					String[] s2 = anterior.getServicio().getHoraServicio().split(":");
					int seg2 = Integer.parseInt(s2[2]);
					
					if (seg>seg2){
						aux = array[y];
						array[y] = array[y-1];
						array[y-1] = aux;
					}
				}
			}
			//Ordenamiento burbuja por minuto
			for(int x=0; x<=max-2; x++){
				for(int y=max-1; y>=x+1; y--){
					
					NodoServicio actual = array[y];
					String[] m1 = actual.getServicio().getHoraServicio().split(":");
					int min = Integer.parseInt(m1[1]);
					
					NodoServicio anterior = array[y-1];
					String[] m2 = anterior.getServicio().getHoraServicio().split(":");
					int min2 = Integer.parseInt(m2[1]);
					
					if (min>min2){
						aux = array[y];
						array[y] = array[y-1];
						array[y-1] = aux;
					}
				}
			}
			//Ordenamiento burbuja por hora
			for(int x=0; x<=max-2; x++){
				for(int y=max-1; y>=x+1; y--){
					
					NodoServicio actual = array[y];
					String[] h1 = actual.getServicio().getHoraServicio().split(":");
					int hor = Integer.parseInt(h1[0]);
					
					NodoServicio anterior = array[y-1];
					String[] h2 = anterior.getServicio().getHoraServicio().split(":");
					int hor2 = Integer.parseInt(h2[0]);
					
					if (hor>hor2){
						aux = array[y];
						array[y] = array[y-1];
						array[y-1] = aux;
					}
				}
			}
			
			//Ordenamiento burbuja por dia
			for(int x=0; x<=max-2; x++){
				for(int y=max-1; y>=x+1; y--){
					
					NodoServicio actual = array[y];
					String[] f1 = actual.getServicio().getFechaServicio().split("-");
					int dia = Integer.parseInt(f1[2]);
					
					NodoServicio anterior = array[y-1];
					String[] f2 = anterior.getServicio().getFechaServicio().split("-");
					int dia2 = Integer.parseInt(f2[2]);
					
					if (dia>dia2){
						aux = array[y];
						array[y] = array[y-1];
						array[y-1] = aux;
					}
				}
			}
			
			// Ordenamiento burbuja por mes
			for(int x=0; x<=max-2; x++){
				for(int y=max-1; y>=x+1; y--){
					
					NodoServicio actual = array[y];
					String[] f1 = actual.getServicio().getFechaServicio().split("-");
					int mes = Integer.parseInt(f1[1]);
					
					NodoServicio anterior = array[y-1];
					String[] f2 = anterior.getServicio().getFechaServicio().split("-");
					int mes2 = Integer.parseInt(f2[1]);
					
					if (mes>mes2){
						aux = array[y];
						array[y] = array[y-1];
						array[y-1] = aux;
					}
				}
			}
			
			// Ordenamiento burbuja por a�o
			for(int x=0; x<=max-2; x++){
				for(int y=max-1; y>=x+1; y--){
					
					NodoServicio actual = array[y];
					String[] f1 = actual.getServicio().getFechaServicio().split("-");
					int ano = Integer.parseInt(f1[0]);

					NodoServicio anterior = array[y-1];
					String[] f2 = anterior.getServicio().getFechaServicio().split("-");
					int ano2 = Integer.parseInt(f2[0]);
					
					if (ano>ano2){
						aux = array[y];
						array[y] = array[y-1];
						array[y-1] = aux;
					}
				}
			}
			
			if(max>1){
				first=null;
				last=null;
			}
			
			for(int x=0; x<max; x++){
				NodoServicio nodoAux = array[x];
				if(max!=1){
					if(x==0){
						first=nodoAux;
						first.setPrevio(null);
						first.setNext(array[x+1]);
						last=nodoAux;
					}else if(x==(max-1)){
						last=nodoAux;
						last.setPrevio(array[x-1]);
						last.setNext(null);
					}else{
						nodoAux.setNext(array[x+1]);
						nodoAux.setPrevio(array[x-1]);
					}
				}
			}
			return true;
		}
	}
}
